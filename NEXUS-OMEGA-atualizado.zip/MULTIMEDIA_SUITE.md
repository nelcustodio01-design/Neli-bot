# 🎬 Multimedia Production Suite

## Descrição Geral

A **Multimedia Production Suite** é um conjunto de 3 comandos avançados que permitem ao bot gerar conteúdo multimedia de alta qualidade, ideal para criadores, estudantes e profissionais.

---

## 📋 Comandos Disponíveis

### 1. 🎨 `.imagine` - Gerador de Imagens AI

**Descrição:** Cria imagens a partir de descrições textuais usando inteligência artificial.

**Sintaxe:**
```
.imagine [descrição da imagem]
```

**Exemplos:**
```
.imagine uma mulher futurista com tecnologia cyberpunk
.imagine paisagem de montanha ao pôr do sol
.imagine gato astronauta no espaço
```

**Características:**
- ✅ Geração de imagens em alta qualidade (1024x1024px)
- ✅ Suporte a descrições em português
- ✅ Integração com IA Manus
- ✅ Processamento rápido (5-10 segundos)
- ✅ Sem limite de gerações por dia

**Limitações:**
- Máximo 500 caracteres na descrição
- Exclusivo para donos do bot
- Requer conexão com API Manus

---

### 2. 📄 `.docgen` - Criador de Documentos Word

**Descrição:** Gera ficheiros `.docx` estruturados e profissionais com conteúdo solicitado.

**Sintaxe:**
```
.docgen [título] | [conteúdo]
```

**Exemplos:**
```
.docgen Relatório Mensal | Este é o conteúdo do relatório de vendas...
.docgen Proposta de Projeto | Descrição detalhada do projeto...
.docgen Certificado | Certificamos que...
```

**Características:**
- ✅ Documentos Word profissionais (.docx)
- ✅ Formatação automática (títulos, datas, rodapés)
- ✅ Suporte a múltiplos parágrafos
- ✅ Design elegante com cores corporativas
- ✅ Compatível com Microsoft Office

**Limitações:**
- Máximo 5000 caracteres no conteúdo
- Exclusivo para donos do bot
- Requer biblioteca `docx`

---

### 3. 📸 `.renderwork` - Conversor de Trabalho para Foto

**Descrição:** Renderiza texto ou documentos em imagens estilizadas HD para partilha rápida.

**Sintaxe:**
```
.renderwork [texto]
ou
[responda a uma mensagem] → .renderwork
```

**Exemplos:**
```
.renderwork Este é um trabalho importante que precisa ser compartilhado...
[responda a um documento] → .renderwork
```

**Características:**
- ✅ Renderização em alta definição (1200x1600px)
- ✅ Design elegante com borda dourada
- ✅ Quebra automática de linhas
- ✅ Rodapé com data e hora
- ✅ Ideal para redes sociais

**Limitações:**
- Máximo 2000 caracteres
- Exclusivo para donos do bot
- Requer biblioteca `canvas`

---

## 🔧 Instalação e Configuração

### Dependências Necessárias

As seguintes dependências foram adicionadas ao `package.json`:

```json
{
  "docx": "^8.5.0",
  "html2canvas": "^1.4.1",
  "sharp": "^0.33.0",
  "pdfkit": "^0.13.0",
  "playwright": "^1.40.0"
}
```

### Instalação

```bash
npm install
```

ou

```bash
pnpm install
```

### Variáveis de Ambiente

Para o comando `.imagine` funcionar, configure:

```env
MANUS_API_KEY=sua_chave_api
MANUS_API_URL=https://api.manus.im
```

---

## 📊 Casos de Uso

### Para Estudantes
- 📝 Gerar documentos de trabalhos escolares
- 🎨 Criar ilustrações para apresentações
- 📸 Renderizar resumos para estudar

### Para Profissionais
- 📄 Criar relatórios e propostas
- 🎨 Gerar imagens para marketing
- 📊 Documentar processos

### Para Criadores
- 🎬 Gerar conteúdo visual
- 📸 Criar imagens para redes sociais
- 📄 Documentar projetos

---

## ⚙️ Configuração Avançada

### Personalizar Estilos de Documentos

Edite `cmds/utils/docgen.js` para alterar:
- Cores do título
- Tamanho de fonte
- Espaçamento de parágrafos
- Fontes utilizadas

### Personalizar Renderização

Edite `cmds/utils/renderwork.js` para alterar:
- Dimensões da imagem
- Cores de fundo
- Estilo de borda
- Tamanho de fonte

---

## 🚀 Deployment

### Replit

1. Faça upload do ficheiro ZIP
2. Execute `npm install`
3. Inicie com `npm start`
4. Os comandos estarão disponíveis automaticamente

### Railway/Heroku

1. Configure as variáveis de ambiente
2. Faça deploy normalmente
3. Os comandos funcionarão sem configuração adicional

---

## 📝 Exemplos Práticos

### Exemplo 1: Gerar Relatório

```
.docgen Relatório de Vendas - Julho 2026 | 
Vendas Totais: 50.000 MZN
Crescimento: +15%
Principais Clientes: ABC Corp, XYZ Ltd
Previsão: Crescimento contínuo esperado
```

### Exemplo 2: Gerar Imagem

```
.imagine Uma mulher executiva em uma sala de reunião moderna, 
com tecnologia futurista, luz natural, fotografia profissional
```

### Exemplo 3: Renderizar Trabalho

```
.renderwork
Resumo: O desenvolvimento sustentável é essencial para o futuro.
Conclusão: Investir em energia renovável é a melhor opção.
```

---

## 🐛 Troubleshooting

### Erro: "API não configurada"
**Solução:** Configure as variáveis de ambiente `MANUS_API_KEY` e `MANUS_API_URL`

### Erro: "Biblioteca não encontrada"
**Solução:** Execute `npm install` novamente

### Imagem não renderiza
**Solução:** Verifique se a biblioteca `canvas` está instalada corretamente

---

## 📞 Suporte

Para reportar problemas ou sugerir melhorias:
- Contacte: Nel Custódio (@custodionel)
- Email: custodionel7@gmail.com
- WhatsApp: +258 878 464 656

---

## 📄 Licença

MIT License - Veja LICENSE para detalhes

---

**Versão:** 1.0.0  
**Última Atualização:** 12 de Julho de 2026  
**Desenvolvido por:** Nel Custódio Aviso Sumaila
