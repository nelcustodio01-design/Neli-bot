import makeWASocket, { useMultiFileAuthState, fetchLatestBaileysVersion, Browsers, makeCacheableSignalKeyStore } from 'baileys';
import pino from 'pino';
import fs from 'fs';
import path from 'path';

async function generateCode(phoneNumber) {
    const sessionDir = './Sessions/TempPairing';
    if (!fs.existsSync(sessionDir)) {
        fs.mkdirSync(sessionDir, { recursive: true });
    }

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        logger: pino({ level: 'silent' }),
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
        }
    });

    if (!sock.authState.creds.registered) {
        try {
            // Aguardar um pouco para inicialização
            await new Promise(resolve => setTimeout(resolve, 5000));
            const code = await sock.requestPairingCode(phoneNumber);
            console.log(`PAIRED_CODE:${code}`);
            process.exit(0);
        } catch (err) {
            console.error('Erro ao gerar código:', err);
            process.exit(1);
        }
    } else {
        console.log('Número já registrado nesta sessão.');
        process.exit(0);
    }
}

const number = process.argv[2];
if (!number) {
    console.error('Por favor, forneça um número de telefone.');
    process.exit(1);
}

generateCode(number);
