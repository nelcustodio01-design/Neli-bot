/**
 * menu_final.js — desativado para evitar conflito com menu.js
 * O menu principal ativo é cmds/main/menu.js
 */
export default {
  command: ['_menu_final_old'],
  category: 'main',
  description: 'Desativado (ver menu.js)',
  run: async ({ msg }) => {}
};
