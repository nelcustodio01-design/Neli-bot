/**
 * ╔══════════════════════════════════════════════════════════════╗
 *   NEL-AVISO-BOT-MOZ · cmds/main/menu_unificado.js
 *   V14 NEXUS SINGULARITY - NEXUS UNIFIED INTERFACE
 *   Refatorado: Apenas visual, sem aliases de outros comandos.
 * ╚══════════════════════════════════════════════════════════════╝
 */

import { getRandomOmegaImage } from '../../core/gallery.js';

export default {
  command: ["menuhd", "nexusmenu"],
  category: "main",
  description: "Interface visual HD com Nexus Visual Engine.",
  run: async ({ sock, msg, usedPrefix }) => {
    try {
      const time = new Date().toLocaleTimeString('pt-PT', { hour12: false });
      const date = new Date().toLocaleDateString('pt-PT');

      const caption = [
        "┏━━━━━━━  『 NEXUS OMEGA EDITION 』  ━━━━━━━┓",
        "┃  ◈ SISTEMA: OMEGA v20 SUPREME           ┃",
        "┃  ◈ ESTADO: 100% STEALTH OMEGA            ┃",
        "┃  ◈ HORA: " + time + " | " + date + "                ┃",
        "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛",
        "",
        "> NEXUS OMEGA: A Singularidade Tecnológica.",
        "",
        "Use *" + usedPrefix + "menu* para o acesso total.",
        "",
        "**© 2024 NEL CUSTÓDIO | BOANE - MOÇAMBIQUE**"
      ].join("\n");

      await msg.react('🌌');
      
      const randomImg = getRandomOmegaImage();

      return sock.sendMessage(msg.chat, {
        image: { url: randomImg },
        caption: caption.trim(),
        contextInfo: { mentionedJid: [msg.sender] }
      }, { quoted: msg });

    } catch (e) {
      console.error('Menu HD Error:', e);
      return msg.reply('⚠️ Erro ao renderizar interface HD.');
    }
  }
};
