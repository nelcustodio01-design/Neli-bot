/**
 * ╔══════════════════════════════════════════════════════════════╗
 *   NEL-AVISO-BOT-MOZ · cmds/main/controle.js
 *   V14 NEXUS SINGULARITY - PAINEL DE CONTROLO DO DONO
 *   Comandos ultra-avançados exclusivos do dono
 * ╚══════════════════════════════════════════════════════════════╝
 */
import db from '#db';
import os from 'os';
import moment from 'moment-timezone';
import { getAntiSleepStats } from '../../core/anti_sleep.js';
import { getOwners } from '../../core/system/owner_manager.js';

function formatUptime(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  return [d && `${d}d`, `${h % 24}h`, `${m % 60}m`, `${s % 60}s`].filter(Boolean).join(' ');
}

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  return (bytes / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
}

export default {
  command: ['controle', 'control', 'painel', 'owner-panel', 'donopanel'],
  category: 'owner',
  description: 'Painel de controlo exclusivo do dono.',
  isOwner: true,
  run: async ({ msg, sock, isOwner }) => {
    if (!isOwner) return msg.reply('🔐 *Acesso negado.* Este painel é exclusivo do dono.');
    
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const settings = db.getSettings(botId) || {};
    const totalUsers = db.getUser()?.length || 0;
    const totalGroups = db.getChat()?.length || 0;
    const uptime = formatUptime(Date.now() - (global.bootTime || Date.now()));
    const hora = moment().tz('Africa/Maputo').format('HH:mm:ss');
    const data = moment().tz('Africa/Maputo').format('DD/MM/YYYY');
    const memUsed = process.memoryUsage();
    const cpuLoad = os.loadavg()[0].toFixed(2);
    const freeRam = formatBytes(os.freemem());
    const totalRam = formatBytes(os.totalmem());
    const owners = getOwners();
    
    let antiSleepStats;
    try { antiSleepStats = getAntiSleepStats(); } catch { antiSleepStats = { isRunning: false, pingCount: 0 }; }

    const panel = `
╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╮
┃  👑 *PAINEL DO DONO — NEXUS V14*
┃  _Acesso Root — Nel Custódio_
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

╭─ 🖥️ *SISTEMA* ───────────────╮
┃  🕒 Hora: *${hora}* | ${data}
┃  ⏱️ Uptime: *${uptime}*
┃  💾 RAM: *${formatBytes(memUsed.heapUsed)}* / ${totalRam}
┃  🔋 RAM Livre: *${freeRam}*
┃  ⚙️ CPU Load: *${cpuLoad}*
┃  📦 Node.js: *${process.version}*
╰──────────────────────────────╯

╭─ 🤖 *BOT STATUS* ────────────╮
┃  👥 Cidadãos: *${totalUsers}*
┃  🏰 Grupos: *${totalGroups}*
┃  🔑 Prefixo: *${settings.prefix || '.'}*
┃  📛 Nome: *${settings.namebot || 'Nel-Aviso'}*
┃  🛡️ Anti-Sleep: *${antiSleepStats.isRunning ? '✅ ATIVO' : '❌ INATIVO'}*
┃  🔄 Pings: *${antiSleepStats.pingCount || 0}*
╰──────────────────────────────╯

╭─ 👑 *DONOS RECONHECIDOS* ────╮
${owners.map(n => `┃  • *+${n}*`).join('\n')}
╰──────────────────────────────╯

╭─ ⚙️ *COMANDOS DO DONO* ──────╮
┃  • *.reload* — Recarregar comandos
┃  • *.restart* — Reiniciar bot
┃  • *.self on/off* — Modo privado
┃  • *.setprefix .* — Alterar prefixo
┃  • *.setname* — Alterar nome
┃  • *.setowner* — Alterar dono
┃  • *.broadcast* — Enviar para todos
┃  • *.ban/unban* — Banir utilizador
╰──────────────────────────────╯

> 🌌 _Nexus Singularity V14 — Poder Total_`;

    await msg.react('👑');
    return msg.reply(panel.trim());
  }
};
