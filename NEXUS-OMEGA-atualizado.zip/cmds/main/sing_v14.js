import { getSignature } from "#system/signature";
import axios from 'axios';

export default {
  name: ["singularity", "ia", "ask"],
  aliases: ["sing", "nexus", "gpt"],
  category: "ia",
  desc: "Acesso à inteligência artificial avançada do bot. Faça uma pergunta ou dê uma instrução.",
  run: async ({ msg, sock, args, usedPrefix, command, settings, isOwner, pushname }) => {
    if (!settings.eliteMode && !isOwner) {
      return msg.reply("💎 *CONTEÚDO ELITE:* Este comando é exclusivo para usuários com o Modo Elite ativado. Peça ao dono para ativar com *.toggleelite*.");
    }

    const query = args.join(" ");
    if (!query) {
      return msg.reply(`Olá! Eu sou a Singularidade V14. Como posso ajudar-te hoje? Exemplo: ${usedPrefix + command} qual é a capital de Moçambique?`);
    }

    await msg.react("🧠");

    try {
      // Integração com uma API de IA real (exemplo com a API de vreden.web.id, se funcional)
      const response = await axios.get(`https://api.vreden.web.id/api/ai/chatgpt?text=${encodeURIComponent(query)}`);
      const result = response.data.result || "O núcleo Singularity está a processar dados complexos. Tenta novamente em instantes.";
      
      const finalMsg = `
╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╮
┃  🧠 *NEXUS SINGULARITY V14*
┃  _Resposta do Núcleo Neural_
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

${result}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
> ⚡ *Nel Custódio: Redefinindo o Impossível.*`;

      return msg.reply(finalMsg.trim() + getSignature());
    } catch (e) {
      console.error("Erro na API de IA:", e);
      return msg.reply("❌ *Erro de Sincronização:* O núcleo neural está temporariamente offline ou houve um problema na comunicação. Tenta novamente mais tarde.\n\n" + getSignature());
    }
  },
};
