import settings from '#settings';
import DB from '#db';
export default {
  command: ['randomsticker', 'stickerrandom', 'aleatoriosticker'],
  category: 'stickers',
  description: 'Sticker aleatorio',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !true) return msg.reply('⚠️ Usa: .randomsticker <texto/URL>\n\n📌 Exemplo: .randomsticker ola mundo');
    await msg.reply(`⏳ A criar sticker...\n\n🎨 Efeito: _randomsticker_\n$\nAguarde...`);
  },
};
