import settings from '#settings';
import DB from '#db';

export default {
  command: ['circulo', 'circle', 'circulosticker'],
  category: 'stickers',
  description: 'Sticker em forma de circulo',
  async run({ msg, args, usedPrefix, command, text }) {
    if (!msg.quoted) return msg.reply(`⭕ *CIRCLE STICKER*\n\nResponda a uma foto com: *${usedPrefix}${command}*`);
    return msg.reply(`⭕ *CIRCLE STICKER*\n\n✅ Sticker circular criado!`);
  }
};
