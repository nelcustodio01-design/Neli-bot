import settings from '#settings';
import DB from '#db';
export default {
  command: ['colorize', 'colorizar', 'colorizesticker'],
  category: 'stickers',
  description: 'Colorizar sticker preto e branco',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .colorize <texto/URL>\n\n📌 Exemplo: .colorize ola mundo');
    await msg.reply(`⏳ A criar sticker...\n\n🎨 Efeito: _colorize_\n$\nAguarde...`);
  },
};
