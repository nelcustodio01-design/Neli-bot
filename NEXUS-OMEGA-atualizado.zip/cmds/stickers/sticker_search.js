import settings from '#settings';
import DB from '#db';
export default {
  command: ['searchsticker', 'searchstick', 'buscarsticker'],
  category: 'stickers',
  description: 'Pesquisar stickers por tema',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query && !false) return msg.reply('⚠️ Usa: .searchsticker <texto/URL>\n\n📌 Exemplo: .searchsticker ola mundo');
    await msg.reply(`⏳ A criar sticker...\n\n🎨 Efeito: _searchsticker_\n$\nAguarde...`);
  },
};
