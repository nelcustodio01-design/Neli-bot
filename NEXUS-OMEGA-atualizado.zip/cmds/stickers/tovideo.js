export default {
  command:['tovideo','s2video','sticker2video','svid'],
  category:'stickers',
  description:'Converter sticker animado em vídeo. 🎥',
  run: async ({ msg, sock, usedPrefix, command }) => {
    const quoted = msg.quoted||msg;
    if (quoted.mtype!=='stickerMessage') return msg.reply(`✎ Responde a um *sticker animado* com *${usedPrefix+command}*`);
    await msg.react('🕒');
    try {
      const buf = await quoted.download();
      await sock.sendMessage(msg.chat,{video:buf,caption:'🎥 _Sticker convertido para vídeo!_\n\n_Nel-Aviso-Bot-Moz 🇲🇿_',mimetype:'video/mp4',gifPlayback:true},{quoted:msg});
      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      return msg.reply(`❧ Erro: ${e.message}`);
    }
  },
};
