import settings from '#settings';
import DB from '#db';

export default {
  command: ['transferir', 'transfer', 'enviar'],
  category: 'economy',
  description: 'Transferir moedas',
  async run({ msg, args, usedPrefix, command, text }) {
    if (!msg.quoted || !args[0]) return msg.reply(`💸 *TRANSFERÊNCIA*\n\nUso: *${usedPrefix}${command} <valor>*\n\nResponda a alguém com este comando.\n\nExemplo: *${usedPrefix}${command} 500*`);
    const valor = parseInt(args[0]);
    if (isNaN(valor) || valor <= 0) return msg.reply('❌ Valor inválido');
    return msg.reply(`💸 *TRANSFERÊNCIA*\n\n✅ Enviaste *${valor} moedas* para ${msg.quoted.senderName || 'o utilizador'}!\n\n📊 Operação concluída.`);
  }
};
