import settings from '#settings';
import DB from '#db';

export default {
  command: ['ranking', 'top10', 'classificacao'],
  category: 'economy',
  description: 'Ranking de moedas',
  async run({ msg, args, usedPrefix, command, text }) {
    const players = [
      { nome: 'Nel', moedas: 50000 },
      { nome: 'Custódio', moedas: 35000 },
      { nome: 'Bot Master', moedas: 28000 },
      { nome: 'Dev', moedas: 22000 },
      { nome: 'Admin', moedas: 15000 },
    ];
    const lista = players.map((p, i) => `${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '  '}. *${p.nome}* - ${p.moedas.toLocaleString()} moedas`).join('\n');
    return msg.reply(`🏆 *TOP 5 RANKING*\n\n${lista}\n\n_Use *${usedPrefix}ranking* para ver a tua posição._`);
  }
};
