import settings from '#settings';
import DB from '#db';

export default {
  command: ['gdrive', 'gdl', 'googledrive'],
  category: 'downloads',
  description: 'Baixar de Google Drive',
  async run({ msg, args, usedPrefix, command, text }) {
    const link = args.join(' ');
    if (!link) return msg.reply(`📁 *GOOGLE DRIVE*\n\nUso: *${usedPrefix}${command} <link gdrive>*\n\nExemplo: *${usedPrefix}${command} https://drive.google.com/file/d/xxxxx*`);
    return msg.reply(`📁 *GOOGLE DRIVE*\n\n🔗 Link: _${link}_\n⏳ A processar...`);
  }
};
