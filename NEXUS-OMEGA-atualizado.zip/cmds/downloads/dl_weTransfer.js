import settings from '#settings';
import DB from '#db';

export default {
  command: ['wetransfer', 'wetdl', 'wet'],
  category: 'downloads',
  description: 'Baixar de WeTransfer',
  async run({ msg, args, usedPrefix, command, text }) {
    const link = args.join(' ');
    if (!link) return msg.reply(`📤 *WETRANSFER*\n\nUso: *${usedPrefix}${command} <link>*\n\nExemplo: *${usedPrefix}${command} https://we.tl/xxxxx*`);
    return msg.reply(`📤 *WETRANSFER*\n\n🔗 Link: _${link}_\n⏳ A processar...`);
  }
};
