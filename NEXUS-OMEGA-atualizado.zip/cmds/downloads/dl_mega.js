import settings from '#settings';
import DB from '#db';

export default {
  command: ['mega', 'megadl', 'megadownload'],
  category: 'downloads',
  description: 'Baixar de MEGA.nz',
  async run({ msg, args, usedPrefix, command, text }) {
    const link = args.join(' ');
    if (!link) return msg.reply(`📥 *MEGA DOWNLOAD*\n\nUso: *${usedPrefix}${command} <link mega.nz>*\n\nExemplo: *${usedPrefix}${command} https://mega.nz/file/xxxxx*`);
    if (!link.includes('mega.nz')) return msg.reply('❌ Link MEGA inválido.');
    return msg.reply(`📥 *MEGA DOWNLOAD*\n\n🔗 Link: _${link}_\n⏳ A processar...\n\n💡 Os ficheiros MEGA são enviados por link directo.`);
  }
};
