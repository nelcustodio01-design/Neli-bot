import settings from '#settings';
import DB from '#db';
export default {
  command: ['medium', 'mediumdl', 'md'],
  category: 'downloads',
  description: 'Baixar artigos do Medium',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .medium <link ou nome>\n\n📌 Exemplo: .medium https://exemplo.com/video');
    await msg.reply(`🔄 A buscar em Medium...\n\n🔍 Query: _${query}_\n⏳ Aguarde...`);
    // API externa para medium
    try {
      // Implementacao real: chamar API de medium
      await msg.reply(`⏳ Processando: _${query}_\n\n💡 Para usar este comando, configure a API correspondente no .env`);
    } catch (e) {
      await msg.reply(`❌ Erro: ${e.message}`);
    }
  },
};
