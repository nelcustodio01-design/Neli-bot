import settings from '#settings';
import DB from '#db';

export default {
  command: ['4shared', '4sdl', '4s'],
  category: 'downloads',
  description: 'Baixar de 4shared',
  async run({ msg, args, usedPrefix, command, text }) {
    const link = args.join(' ');
    if (!link) return msg.reply(`📂 *4SHARED*\n\nUso: *${usedPrefix}${command} <link 4shared>*\n\nExemplo: *${usedPrefix}${command} https://www.4shared.com/file/xxxxx*`);
    return msg.reply(`📂 *4SHARED*\n\n🔗 Link: _${link}_\n⏳ A processar...`);
  }
};
