import DB from '#db';

export default {
  command: ['bemvindo', 'entrada'],
  category: 'moderacao',
  description: 'Mensagem de boas-vindas',
  groupOnly: true,
  isAdmin: true,
  async run({ msg, args, usedPrefix, command }) {
    const activar = args[0] && args[0].toLowerCase();
    if (!activar) return msg.reply(
      '👋 *BOAS-VINDAS*\n\n' +
      'Uso: *' + usedPrefix + command + ' on/off*\n\n' +
      '• *' + usedPrefix + command + ' on* — Activar\n' +
      '• *' + usedPrefix + command + ' off* — Desactivar'
    );
    if (activar === 'on') {
      DB.setChat(msg.chat, 'welcome', 1);
      return msg.reply('👋 *Boas-vindas ativadas.* Novos membros receberão a mensagem configurada.');
    }
    if (activar === 'off') {
      DB.setChat(msg.chat, 'welcome', 0);
      return msg.reply('👋 *Boas-vindas desativadas.*');
    }
    return msg.reply('❌ Use *on* ou *off*');
  }
};
