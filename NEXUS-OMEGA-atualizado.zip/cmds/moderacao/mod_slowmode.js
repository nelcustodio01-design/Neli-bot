import DB from '#db';

export default {
  command: ['slowmode', 'modolento', 'slow'],
  category: 'moderacao',
  description: 'Definir o intervalo mínimo entre mensagens de cada membro.',
  groupOnly: true,
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, args, usedPrefix, command }) => {
    const action = (args[0] || 'status').toLowerCase();
    const current = Number(DB.getChat(msg.chat)?.slowmodeSeconds) || 0;
    if (action === 'status') {
      return msg.reply(`Modo lento: *${current ? `${current} segundos` : 'desativado'}*.\nUso: *${usedPrefix + command} 5* ou *${usedPrefix + command} off*.`);
    }
    if (['off', 'desativar', '0'].includes(action)) {
      DB.setChat(msg.chat, 'slowmodeSeconds', 0);
      return msg.reply('Modo lento desativado.');
    }
    const seconds = Number(action);
    if (!Number.isInteger(seconds) || seconds < 2 || seconds > 600) {
      return msg.reply(`Indique um intervalo entre *2 e 600 segundos* ou use *${usedPrefix + command} off*.`);
    }
    DB.setChat(msg.chat, 'slowmodeSeconds', seconds);
    return msg.reply(`Modo lento ativado: cada membro pode enviar uma mensagem a cada *${seconds} segundos*. Administradores ficam isentos.`);
  },
};
