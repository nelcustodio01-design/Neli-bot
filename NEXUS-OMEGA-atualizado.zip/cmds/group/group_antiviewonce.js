export default {
  command: ['antiviewonce', 'antiview', 'antivv'],
  category: 'group',
  description: 'Explicar o limite de mensagens de visualização única.',
  groupOnly: true,
  isAdmin: true,
  async run({ msg }) {
    return msg.reply(
      'O WhatsApp não oferece ao bot uma forma suportada de desbloquear ou recuperar mídia de visualização única. ' +
      'Peça ao remetente que envie novamente como mídia normal.'
    );
  },
};
