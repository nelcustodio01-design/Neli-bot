export default {
  command: ['kickall', 'expulsartodos', 'limpargrupo'],
  category: 'group',
  description: 'Mostrar uma prévia de membros não administradores; remoção em massa não é executada.',
  groupOnly: true,
  isAdmin: true,
  botAdmin: true,
  async run({ msg, participants = [] }) {
    const botId = String(msg.key?.participant || '').split(':')[0];
    const eligible = participants.filter(participant => {
      const jid = participant.id || '';
      return jid && jid !== botId && !participant.admin;
    });
    if (!eligible.length) return msg.reply('Não há membros não administradores para listar.');
    const preview = eligible.slice(0, 40).map((participant, index) =>
      `${index + 1}. @${(participant.id || '').split('@')[0].split(':')[0]}`).join('\n');
    const extra = eligible.length > 40 ? `\n… e mais ${eligible.length - 40} membros.` : '';
    return msg.reply(`*Prévia — ${eligible.length} membros não administradores*\n${preview}${extra}\n\nPor segurança, este comando não expulsa o grupo inteiro. Use *kick @membro* para analisar e remover uma pessoa de cada vez.`);
  },
};
