import db from '#db';

const DAY = 24 * 60 * 60 * 1000;

function lastActiveMs(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'string') {
    const numeric = Number(value);
    if (Number.isFinite(numeric) && numeric > 0) return numeric;
    const parsed = Date.parse(value);
    if (Number.isFinite(parsed)) return parsed;
  }
  return 0;
}

export default {
  command: ['clear'],
  category: 'grupos',
  description: 'Consultar e limpar dados de jogo de membros inativos.',
  groupOnly: true,
  isAdmin: true,
  run: async ({ msg, args, usedPrefix, command }) => {
    const mode = (args[0] || 'view').toLowerCase();
    const confirmed = args.some(value => value.toLowerCase() === 'confirm');
    const cutoff = Date.now() - 30 * DAY;
    const inactive = db.getChatUser(msg.chat)
      .map(user => ({ ...user, lastActiveMs: lastActiveMs(user.lastActive) }))
      .filter(user => user.lastActiveMs > 0 && user.lastActiveMs < cutoff)
      .sort((a, b) => a.lastActiveMs - b.lastActiveMs);

    if (!['view', 'ver', 'delete', 'del', 'full'].includes(mode)) {
      return msg.reply(
        `Uso:\n• *${usedPrefix + command} view* — listar inativos há mais de 30 dias\n` +
        `• *${usedPrefix + command} delete confirm* — zerar moedas e personagens desses registos\n` +
        `• *${usedPrefix + command} full confirm* — apagar os registos de jogo desses membros`
      );
    }
    if (inactive.length === 0) {
      return msg.reply('Não há registos com atividade anterior a 30 dias. O bot começa a contar atividade a partir de agora.');
    }

    const list = inactive.slice(0, 30).map(user => {
      const days = Math.floor((Date.now() - user.lastActiveMs) / DAY);
      return `• @${user.user_id.split('@')[0]} — ${days} dias sem atividade`;
    }).join('\n');
    const overflow = inactive.length > 30 ? `\n… e mais ${inactive.length - 30} registos.` : '';

    if (['view', 'ver'].includes(mode)) {
      return msg.reply(`*Prévia — inativos há mais de 30 dias (${inactive.length})*\n${list}${overflow}\n\nEsta limpeza altera apenas os dados de jogo do bot; não remove membros do WhatsApp.`);
    }
    if (!confirmed) {
      const action = mode === 'full'
        ? 'apagar por completo os registos de jogo, avisos e estatísticas listados'
        : 'zerar moedas e personagens dos registos listados';
      return msg.reply(`A ação vai ${action}. Ela não pode ser desfeita.\n\nPrévia (${inactive.length} registos):\n${list}${overflow}\n\nPara confirmar, envie *${usedPrefix + command} ${mode} confirm*.`);
    }

    for (const user of inactive) {
      let characters = Array.isArray(user.characters) ? user.characters : [];
      for (const characterId of characters) {
        const character = db.getCharacter(characterId);
        if (character?.user === user.user_id) {
          db.setCharacter(characterId, { user: '', claimedAt: 0 });
        }
      }
      if (mode === 'full') {
        db.deleteChatUser(msg.chat, user.user_id);
      } else {
        db.setChatUser(msg.chat, user.user_id, 'characters', []);
        db.setChatUser(msg.chat, user.user_id, 'favorite', '');
        db.setChatUser(msg.chat, user.user_id, 'coins', 0);
        db.setChatUser(msg.chat, user.user_id, 'bank', 0);
      }
    }
    return msg.reply(`Limpeza concluída: ${inactive.length} registos ${mode === 'full' ? 'apagados' : 'de dados de jogo repostos'}. Nenhum membro foi removido do WhatsApp.`);
  },
};
