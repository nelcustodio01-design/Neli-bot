export default {
  command: ['antibot', 'antibots', 'blockbot'],
  category: 'group',
  description: 'Informar sobre as limitações de identificação de bots no WhatsApp.',
  groupOnly: true,
  isAdmin: true,
  async run({ msg }) {
    return msg.reply(
      'O WhatsApp não informa de forma confiável se um participante usa outro bot. ' +
      'Por isso, este comando não expulsa pessoas nem identifica contas por suposição. ' +
      'Revise o participante e use *kick @membro* se a remoção for necessária.'
    );
  },
};
