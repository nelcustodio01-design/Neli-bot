import db from '#db';
import settings from '#settings';

const digits = value => String(value || '').split('@')[0].split(':')[0].replace(/\D/g, '');
const isAdmin = participant => participant?.admin === 'admin' || participant?.admin === 'superadmin';

function previewList(jids, title) {
  const rows = jids.slice(0, 35).map((jid, index) => `${index + 1}. @${jid.split('@')[0]}`).join('\n');
  return `*${title} (${jids.length})*\n${rows}${jids.length > 35 ? `\n… e mais ${jids.length - 35} membros.` : ''}\n\nEsta opção apenas lista os membros; use *kick @membro* para remover uma pessoa de cada vez.`;
}

export default {
  command: ['kick', 'ban', 'bang'],
  category: 'grupos',
  description: 'Remover um membro específico do grupo ou listar candidatos para revisão.',
  groupOnly: true,
  isAdmin: true,
  botAdmin: true,
  run: async ({ msg, sock, args, usedPrefix, command, groupMetadata, participants = [] }) => {
    const ownerNumbers = [...(settings.ownerNumbers || []), settings.ownerNumber]
      .filter(Boolean).map(digits);
    const ownerGroup = digits(groupMetadata?.owner);
    const botId = digits(sock.user?.id);
    const query = (args[0] || '').toLowerCase();

    if (['all', 'todos'].includes(query)) {
      const candidates = participants.filter(p => p.id && !isAdmin(p)
        && digits(p.id) !== botId && digits(p.id) !== ownerGroup).map(p => p.id);
      if (!candidates.length) return msg.reply('Não encontrei membros não administradores.');
      return msg.reply(previewList(candidates, 'Prévia de membros'));
    }

    if (['num', 'listnum'].includes(query)) {
      const prefix = String(args[1] || '').replace(/\D/g, '');
      if (!prefix) return msg.reply(`Indique o código do país. Exemplo: *${usedPrefix + command} listnum 258*`);
      const matches = participants.filter(p => p.id && digits(p.id).startsWith(prefix)).map(p => p.id);
      if (!matches.length) return msg.reply(`Não encontrei números com o prefixo +${prefix}.`);
      return msg.reply(previewList(matches, `Números com +${prefix}`));
    }

    if (['inactive', 'listinactive', 'inativos'].includes(query)) {
      const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1000;
      const records = db.getChatUser(msg.chat);
      const candidates = participants.filter(participant => {
        if (!participant.id || isAdmin(participant) || digits(participant.id) === botId) return false;
        const record = records.find(user => digits(user.user_id) === digits(participant.id));
        return Number(record?.lastActive) > 0 && Number(record.lastActive) < cutoff;
      }).map(participant => participant.id);
      if (!candidates.length) return msg.reply('Não há membros com atividade registada há mais de 30 dias. O bot começa a contar atividade a partir de agora.');
      return msg.reply(previewList(candidates, 'Prévia de membros inativos'));
    }

    const rawTarget = msg.mentionedJid?.[0] || msg.quoted?.sender;
    if (!rawTarget) {
      return msg.reply(
        `Mencione uma pessoa ou responda à mensagem dela.\nExemplo: *${usedPrefix + command} @membro*\n\n` +
        `*all*, *num <código>* e *inactive* apenas mostram prévias; não removem grupos inteiros.`
      );
    }
    const participant = participants.find(item => digits(item.id) === digits(rawTarget)
      || digits(item.lid) === digits(rawTarget));
    if (!participant) return msg.reply('Esse membro já não aparece na lista atual do grupo.');
    if (isAdmin(participant)) return msg.reply('Não vou remover um administrador por este comando.');
    if (digits(participant.id) === botId) return msg.reply('Não posso remover o próprio bot do grupo.');
    if (digits(participant.id) === ownerGroup) return msg.reply('Não posso remover o proprietário do grupo.');
    if (ownerNumbers.includes(digits(participant.id))) return msg.reply('Não posso remover o proprietário do bot.');

    try {
      await sock.groupParticipantsUpdate(msg.chat, [participant.id], 'remove');
      return msg.reply(`Membro @${digits(participant.id)} removido do grupo.`, { mentions: [participant.id] });
    } catch (error) {
      return msg.reply(`Não consegui remover esse membro. Confirme se o bot continua administrador do grupo. (${error.message})`);
    }
  },
};
