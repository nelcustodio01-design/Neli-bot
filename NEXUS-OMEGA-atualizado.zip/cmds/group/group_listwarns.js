import DB from '#db';
export default {
  command: ['listwarns', 'veravisos', 'warnings'],
  category: 'group',
  description: 'Ver avisos de um membro',
  groupOnly: true,
  isAdmin: true,
  async run({ msg, sock }) {
    const userId = msg.mentionedJid?.[0] || msg.quoted?.sender;
    if (!userId) return msg.reply('Mencione um membro ou responda à mensagem dele para consultar os avisos.');
    const user = DB.getChatUser(msg.chat, userId);
    const warnings = Array.isArray(user?.warnings) ? user.warnings : [];
    if (!warnings.length) return msg.reply(`@${userId.split('@')[0]} não tem avisos registados.`, { mentions: [userId] });
    const text = warnings.map((warning, index) =>
      `${index + 1}. ${warning.reason || 'Sem motivo'} — ${warning.timestamp || 'data não registada'}`).join('\n');
    return sock.reply(msg.chat, `*Avisos de @${userId.split('@')[0]} (${warnings.length})*\n${text}`, msg, { mentions: [userId] });
  },
};
