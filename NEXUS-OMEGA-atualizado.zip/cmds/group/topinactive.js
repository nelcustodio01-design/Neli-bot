import db from '#db';
export default {
  command: ['topinactive', 'topinactivos', 'topinactiveusers'],
  category: 'grupos',
  description: 'Ver o top de usuários mais inactivos do grupo.',
  groupOnly: true,
  run: async ({ msg, sock, args, usedPrefix, text }) => {
    const chatId = msg.chat;
    const allChatUsers = db.getChatUser(chatId);
    const now = new Date();
    let daysArg = args[0] ? parseInt(args[0]) : 30;
    if (daysArg < 1) daysArg = 30;
    const cutoff = new Date(now.getTime() - daysArg * 24 * 60 * 60 * 1000);
    const ranking = [];
    for (const user of allChatUsers) {
      const stats = user.stats && typeof user.stats === 'object' ? user.stats : {};
      const days = Object.entries(stats).filter(([date]) => new Date(date) >= cutoff);
      const totalMsgs = days.reduce((acc, [, d]) => acc + (Number(d.msgs) || 0), 0);
      const lastActive = Number(user.lastActive) || 0;
      ranking.push({ jid: user.user_id, totalMsgs, lastActive });
    }
    ranking.sort((a, b) => a.lastActive - b.lastActive || a.totalMsgs - b.totalMsgs);
    if (ranking.length === 0) {
      return msg.reply(`「✎」 Não há atividade registada nos últimos ${daysArg} dias.`);
    }
    const page = parseInt(args[1]) || 1;
    const perPage = 10;
    const totalPages = Math.ceil(ranking.length / perPage);
    if (page < 1 || page > totalPages) {
      return msg.reply(`「✎」 Página inválida. Só há ${totalPages} páginas disponíveis.`);
    }
    const start = (page - 1) * perPage;
    const end = start + perPage;
    const pageRanking = ranking.slice(start, end);
    let report = `❀ Top de usuários inactivos ❀\n`;
    report += `> » Días: \`${daysArg}\`\n`;
    report += `> » Página: \`${page}\` de \`${totalPages}\`\n\n`;
    const mentions = [];
    for (let i = 0; i < pageRanking.length; i++) {
      const u = pageRanking[i];
      const userGlobal = db.getUser(u.jid);
      const name = userGlobal?.name || '@' + u.jid.split('@')[0];
      report += `*${start + i + 1}.* ${name}\n`;
      report += `   » Mensagems: \`${u.totalMsgs}\`\n`;
      mentions.push(u.jid);
    }
    if (page < totalPages) {
      report += `\n> Para ver a próxima página › *${text + usedPrefix} ${daysArg} ${page + 1}*`;
    }
    await sock.reply(chatId, report, msg, { mentions });
  }
};