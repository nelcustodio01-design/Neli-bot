import DB from '#db';
export default {
  command: ['restore', 'restaurar', 'restaurargrupo'],
  category: 'group',
  description: 'Restaurar backup do grupo',
  groupOnly: true,
  isAdmin: true,
  async run({ msg, args, usedPrefix, command }) {
    const action = (args[0] || 'list').toLowerCase();
    const backups = DB.listGroupBackups(msg.chat);
    if (['list', 'listar', 'ver'].includes(action)) {
      if (!backups.length) return msg.reply('Ainda não há backups deste grupo. Crie um com *backup*.');
      const list = backups.map(item => {
        const date = new Date(item.created_at).toLocaleString('pt-MZ', { timeZone: 'Africa/Maputo' });
        return `• ID *${item.id}* — ${date}`;
      }).join('\n');
      return msg.reply(`*Backups das configurações*\n${list}\n\nPara restaurar: *${usedPrefix + command} <ID> confirmar*`);
    }
    const id = Number(action);
    if (!Number.isInteger(id) || id < 1) return msg.reply(`Uso: *${usedPrefix + command} listar* ou *${usedPrefix + command} <ID> confirmar*`);
    if (!args.some(value => ['confirmar', 'confirm'].includes(value.toLowerCase()))) {
      return msg.reply(`Restaurar o backup *${id}* substitui as configurações atuais deste grupo. Os dados de jogo dos membros não são alterados.\nConfirme com: *${usedPrefix + command} ${id} confirmar*`);
    }
    if (!DB.restoreGroupBackup(msg.chat, id)) return msg.reply(`Não encontrei o backup *${id}* deste grupo.`);
    return msg.reply(`As configurações do grupo foram restauradas a partir do backup *${id}*.`);
  },
};
