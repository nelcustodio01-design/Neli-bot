import db from '#db';
import multibots from '../../core/multibots.js';

const jidNumber = jid => String(jid || '').split('@')[0].split(':')[0].replace(/\D/g, '');

export default {
  command: ['setprimary'],
  category: 'grupos',
  description: 'Escolher qual bot conectado responde neste grupo.',
  groupOnly: true,
  isAdmin: true,
  run: async ({ msg, sock, usedPrefix, command, participants = [] }) => {
    const target = msg.mentionedJid?.[0] || msg.quoted?.sender;
    if (!target) {
      const current = db.getChat(msg.chat)?.primaryBot;
      return msg.reply(
        `Mencione o bot que ficará ativo neste grupo.\n` +
        `Uso: *${usedPrefix + command} @bot*\n` +
        `Bot atual: ${current ? `@${jidNumber(current)}` : 'principal'}.\n` +
        `Só são aceitos o bot principal e sessões secundárias que estejam online.`
      );
    }

    const participant = participants.find(item =>
      jidNumber(item.id) === jidNumber(target) || jidNumber(item.lid) === jidNumber(target));
    if (!participant) return msg.reply('Esse bot não está presente no grupo.');
    const requested = participant.id;
    const connectedBots = [sock.user?.id, ...multibots.listBotJids()].filter(Boolean);
    if (!connectedBots.some(jid => jidNumber(jid) === jidNumber(requested))) {
      return msg.reply('A conta mencionada não é o bot principal nem uma sessão secundária conectada.');
    }

    db.setChat(msg.chat, 'primaryBot', requested);
    return sock.reply(
      msg.chat,
      `@${jidNumber(requested)} foi definido como o bot que responde neste grupo.`,
      msg,
      { mentions: [requested] }
    );
  },
};
