import DB from '#db';
export default {
  command: ['antitago', 'antitagar', 'noatag'],
  category: 'group',
  description: 'Ativar ou desativar a remoção de mensagens com menções de membros.',
  groupOnly: true,
  isAdmin: true,
  botAdmin: true,
  async run({ msg, args, usedPrefix, command }) {
    const action = (args[0] || 'status').toLowerCase();
    if (!['on', 'off', 'status'].includes(action)) {
      return msg.reply(`Uso: *${usedPrefix + command} on|off|status*`);
    }
    if (action === 'status') {
      const enabled = Boolean(DB.getChat(msg.chat)?.antitago);
      return msg.reply(`Anti-menções: *${enabled ? 'ativado' : 'desativado'}*.`);
    }
    DB.setChat(msg.chat, 'antitago', action === 'on' ? 1 : 0);
    return msg.reply(`Anti-menções ${action === 'on' ? 'ativado' : 'desativado'}.`);
  },
};
