import settings from '#settings';
import DB from '#db';
export default {
  command: ['poemaia', 'poema', 'versos'],
  category: 'ia',
  description: 'Criar poema com IA',
  async run({ msg, sock, args, text }) {
    const query = args.join(' ');
    if (!query) return msg.reply('⚠️ Usa: .poemaia <texto>\n\n📌 Exemplo: .poemaia como funciona o WhatsApp?');
    await msg.reply(`🤖 A pensar...\n\n🧠 IA: _poemaia_\n📝 Query: _${query}_\n⏳ Aguarde...`);
  },
};
