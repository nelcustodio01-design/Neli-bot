import db from '#db';
import { askNexus } from '../../core/system/nexus_intelligence.js';

export default {
  command: ['architect', 'vision-pro', 'deep-mind', 'voice-clone', 'poesia', 'art-studio'],
  category: 'singularity',
  description: 'Comandos de ultra-tecnologia Nexus Singularity V14 com IA Real.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const user = db.getUser(msg.sender);
    const isOwner = global.owner.includes(msg.sender.split('@')[0]);

    if (!user.vip && !isOwner) {
      return msg.reply('💎 Este comando requer nível *NEXUS ELITE (VIP)*.\n> Digite .vip para saber como adquirir.');
    }

    if (!args[0] && command !== 'poesia' && command !== 'nexus') 
        return msg.reply(`💡 Uso: ${usedPrefix}${command} <sua solicitação>`);

    await msg.react('🧠');
    const query = args.join(' ');

    try {
      switch (command) {
        case 'nexus':
        case 'deep-mind':
          const aiResponse = await askNexus(msg.sender, query);
          return msg.reply(`🧠 *NEXUS SINGULARITY V14*\n\n${aiResponse}\n\n> _Processado via Redes Neurais Nel-Aviso_`);

        case 'architect':
          const codeResponse = await askNexus(msg.sender, query, "Você é um arquiteto de software sênior. Forneça estruturas de código completas, limpas e profissionais.");
          return msg.reply(`🏗️ *NEXUS CODE ARCHITECT*\n\n${codeResponse}`);
        
        case 'poesia':
          const poemPrompt = query || 'a singularidade tecnológica e o génio de Nel Custódio';
          const poem = await askNexus(msg.sender, `Escreva uma poesia épica sobre: ${poemPrompt}`, "Você é um poeta tecnológico moçambicano renomado.");
          return msg.reply(`📜 *POESIA ETERNA*\n\n${poem}`);

        case 'vision-pro':
          if (!msg.quoted || !/image/.test(msg.quoted.mimetype)) 
              return msg.reply('👁️ Por favor, responda a uma *imagem* para análise multiespectral.');
          return msg.reply('👁️ *Vision Pro:* Analisando camadas de dados... (Funcionalidade em integração com motor Gemini Pro Vision)');

        case 'art-studio':
          return msg.reply(`🎨 *ART STUDIO:* Use o comando *${usedPrefix}gerar-imagem* para acessar o motor DALL-E 3 otimizado.`);

        default:
          return msg.reply('Comando em fase de teste beta.');
      }
    } catch (e) {
      msg.reply('❌ Erro no motor Singularity: ' + e.message);
    }
  }
};
