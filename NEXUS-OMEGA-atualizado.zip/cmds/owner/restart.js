export default {
  command: ['restart'],
  category: 'owner',
  description: 'Reiniciar el socket do bot.',
  isOwner: true,
  run: async ({ msg, sock, isOwner }) => {
    if (!isOwner) return sock.sendMessage(msg.chat, { text: '🔒 Apenas o dono pode reiniciar o bot.' }, { quoted: msg });
    await sock.reply(msg.chat, `✎ Reiniciando el Socket...\n> *Espere un momento...*`, msg);
    setTimeout(() => {
      if (process.send) {
        process.send("restart");
      } else {
        process.exit(0);
      }
    }, 3000);
  },
};