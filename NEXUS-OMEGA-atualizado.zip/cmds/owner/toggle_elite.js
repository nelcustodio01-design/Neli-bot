import db from '#db';

export default {
  name: 'toggleelite',
  aliases: ['eliteon', 'eliteoff'],
  category: 'owner',
  desc: 'Ativa ou desativa o modo Elite para todos os usuários. Comandos de IA serão restritos se desativado.',
  run: async ({ msg, sock, args, isOwner, settings, botJid }) => {
    if (!isOwner) {
      return msg.reply('Apenas o dono do bot pode usar este comando.');
    }

    let newEliteMode = !settings.eliteMode;
    if (args[0]) {
      const arg = args[0].toLowerCase();
      if (arg === 'on') newEliteMode = true;
      else if (arg === 'off') newEliteMode = false;
    }

    db.setSettings(botJid, 'eliteMode', newEliteMode);
    const status = newEliteMode ? 'ativado' : 'desativado';
    await msg.reply(`✅ O Modo Elite foi *${status}* para todos os usuários.`);
  },
};
