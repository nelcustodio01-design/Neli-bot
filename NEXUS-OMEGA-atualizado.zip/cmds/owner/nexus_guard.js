import { exec } from 'child_process';
import { promisify } from 'util';
import chalk from 'chalk';

const execPromise = promisify(exec);

export default {
  name: ["nexusguard", "scan", "audit"],
  aliases: ["nguard", "seguranca"],
  category: "owner",
  desc: "Ferramentas de auditoria e segurança para o bot. Apenas para o dono.",
  run: async ({ msg, sock, args, isOwner, usedPrefix, command }) => {
    if (!isOwner) {
      return msg.reply("Apenas o dono do bot pode usar este comando.");
    }

    const subCommand = args[0]?.toLowerCase();

    switch (subCommand) {
      case "files":
        try {
          await msg.reply("🔍 A fazer uma auditoria de ficheiros críticos... Isso pode demorar um pouco.");
          const { stdout } = await execPromise("find . -type f -name \"*.js\" -not -path \"./node_modules/*\" -exec grep -lE \"process.env|eval\\(|setTimeout\\(|setInterval\\(|exec\\(|spawn\\(|fork\\(|fs.writeFile\\(|fs.appendFile\\(|fs.unlink\\(|rm -rf\" {} + || echo \"Nenhum ficheiro suspeito encontrado.\"");
          await msg.reply(`*Relatório de Auditoria de Ficheiros Suspeitos:*\n\n${stdout}`);
        } catch (error) {
          await msg.reply(`Erro ao auditar ficheiros: ${error.message}`);
        }
        break;
      case "deps":
        try {
          await msg.reply("📦 A verificar dependências desatualizadas e vulnerabilidades...");
          const { stdout } = await execPromise("npm audit --json || echo \"Nenhuma vulnerabilidade crítica encontrada.\"");
          const auditResult = JSON.parse(stdout);
          if (auditResult.metadata.vulnerabilities.total > 0) {
            await msg.reply(`*Relatório de Vulnerabilidades de Dependências:*\n\nTotal de vulnerabilidades: ${auditResult.metadata.vulnerabilities.total}\n\nPara mais detalhes, execute 'npm audit' no terminal do Replit.`);
          } else {
            await msg.reply("✅ Nenhuma vulnerabilidade crítica de dependências encontrada.");
          }
        } catch (error) {
          await msg.reply(`Erro ao auditar dependências: ${error.message}`);
        }
        break;
      case "logs":
        try {
          await msg.reply("📄 A recolher os últimos logs de erro...");
          const { stdout } = await execPromise("tail -n 100 error.log || echo \"Nenhum log de erro encontrado.\"");
          await msg.reply(`*Últimos 100 Logs de Erro:*\n\n${stdout}`);
        } catch (error) {
          await msg.reply(`Erro ao recolher logs: ${error.message}`);
        }
        break;
      default:
        await msg.reply(`*Comandos do Nexus Guard:*\n\n> ${usedPrefix}nexusguard files - Audita ficheiros por código suspeito.\n> ${usedPrefix}nexusguard deps - Verifica dependências por vulnerabilidades.\n> ${usedPrefix}nexusguard logs - Mostra os últimos logs de erro.`);
        break;
    }
  },
};
