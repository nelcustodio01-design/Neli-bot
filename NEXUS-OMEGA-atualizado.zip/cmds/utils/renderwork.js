/**
 * .renderwork - Conversor de Trabalho para Foto
 * Renderiza texto/documento numa imagem estilizada HD
 * Uso: .renderwork [texto ou responder a mensagem]
 */

import { writeFileSync } from 'fs';
import { join } from 'path';
import { randomBytes } from 'crypto';

export default {
  command: ['renderwork', 'render', 'renderizar', 'trabalho'],
  category: 'utils',
  description: 'Renderiza texto em imagem estilizada HD',
  usage: '.renderwork [texto]',
  ownerOnly: true,
  run: async function (msg, sock, args, text, usedPrefix, command, isOwner, isGroup) {
    try {
      if (!isOwner && !isGroup) {
        return msg.reply('❌ Este comando é exclusivo para donos do bot!');
      }

      let textToRender = '';

      if (msg.quoted) {
        textToRender = msg.quoted.body || msg.quoted.text || '';
      } else if (args.length) {
        textToRender = args.join(' ');
      } else {
        return msg.reply(
          '📸 *Renderizador de Trabalhos*\n\n' +
          'Uso: `.renderwork [texto]` ou responda a uma mensagem\n\n' +
          'Converte texto em imagem estilizada HD para partilha rápida!'
        );
      }

      if (textToRender.length > 2000) {
        return msg.reply('❌ Texto muito longo! Máximo 2000 caracteres.');
      }

      const processing = await msg.reply(
        '🎨 Renderizando trabalho em imagem...\n' +
        'Por favor, aguarde...'
      );

      try {
        const imagePath = await renderTextToImage(textToRender);

        if (!imagePath) {
          return msg.reply('❌ Erro ao renderizar imagem!');
        }

        await sock.sendMessage(msg.chat, {
          image: { url: `file://${imagePath}` },
          caption:
            `✅ *Trabalho Renderizado com Sucesso!*\n\n` +
            `📄 Caracteres: ${textToRender.length}\n` +
            `⏰ Data: ${new Date().toLocaleDateString('pt-MZ')}\n` +
            `🤖 Renderizador: Nel-Aviso-Bot`
        }, { quoted: msg });

        await sock.sendMessage(msg.chat, { delete: processing.key });

      } catch (error) {
        console.error('Erro ao renderizar:', error);
        return msg.reply('❌ Erro ao processar renderização!');
      }

    } catch (error) {
      console.error('Erro em renderwork:', error);
      msg.reply('❌ Erro ao processar comando renderwork!');
    }
  }
};

async function renderTextToImage(text) {
  try {
    const { createCanvas } = await import('canvas');
    const width = 1200;
    const height = 1600;
    const padding = 60;
    const lineHeight = 40;
    const fontSize = 28;

    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = '#FAFAFA';
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = '#D4AF37';
    ctx.lineWidth = 3;
    ctx.strokeRect(15, 15, width - 30, height - 30);

    ctx.fillStyle = '#1A1A1A';
    ctx.font = `${fontSize}px 'Arial', sans-serif`;
    ctx.textAlign = 'left';

    const lines = wrapText(ctx, text, width - (padding * 2), fontSize);

    let y = padding + 40;
    lines.forEach((line) => {
      if (y + lineHeight < height - padding) {
        ctx.fillText(line, padding, y);
        y += lineHeight;
      }
    });

    ctx.fillStyle = '#999999';
    ctx.font = `14px 'Arial', sans-serif`;
    ctx.textAlign = 'right';
    ctx.fillText(
      `Nel-Aviso-Bot • ${new Date().toLocaleDateString('pt-MZ')}`,
      width - padding,
      height - padding + 20
    );

    const fileName = `render_${randomBytes(4).toString('hex')}.png`;
    const filePath = join(process.cwd(), 'temp', fileName);
    const buffer = canvas.toBuffer('image/png');
    writeFileSync(filePath, buffer);

    return filePath;

  } catch (error) {
    console.error('Erro ao renderizar imagem:', error);
    return null;
  }
}

function wrapText(ctx, text, maxWidth, fontSize) {
  const words = text.split(' ');
  const lines = [];
  let currentLine = '';

  words.forEach(word => {
    const testLine = currentLine + (currentLine ? ' ' : '') + word;
    const metrics = ctx.measureText(testLine);

    if (metrics.width > maxWidth && currentLine) {
      lines.push(currentLine);
      currentLine = word;
    } else {
      currentLine = testLine;
    }
  });

  if (currentLine) {
    lines.push(currentLine);
  }

  return lines;
}
