/**
 * 🔊 TTS — Texto para Voz em múltiplas línguas
 * Corrigido: APIs robustas, múltiplos idiomas, fallbacks
 */
import fetch from 'node-fetch';
import fs from 'fs';

export default {
  command: ['tts', 'falar', 'textovoz', 'voztexto'],
  category: 'utilidades',
  description: 'Converter texto em voz (múltiplos idiomas) 🔊',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    let lang = 'pt';
    let text = args.join(' ').trim();

    // Detectar idioma no início: .tts pt Olá / .tts en Hello
    if (args[0]?.length === 2 && /^[a-z]+$/.test(args[0])) {
      lang = args[0].toLowerCase();
      text = args.slice(1).join(' ').trim();
    }

    // Texto da mensagem citada
    if (!text && msg.quoted) {
      text = msg.quoted.text || msg.quoted.body || msg.quoted.caption || '';
    }

    if (!text) {
      return msg.reply(
        `🔊 *TTS — TEXTO PARA VOZ*\n\n` +
        `▸ Uso: *${usedPrefix}${command} [idioma] <texto>*\n\n` +
        `▸ Exemplos:\n` +
        `  *${usedPrefix}${command} Olá, como estás?*\n` +
        `  *${usedPrefix}${command} pt Bom dia Moçambique!*\n` +
        `  *${usedPrefix}${command} en Hello world*\n` +
        `  *${usedPrefix}${command} es Buenos días*\n\n` +
        `▸ Idiomas: pt, en, es, fr, de, it, ja, ko, zh, ru, ar, id`
      );
    }

    if (text.length > 500) text = text.substring(0, 500);

    await msg.react('🔊');

    try {
      if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp', { recursive: true });
      const tmpFile = `./tmp/tts_${Date.now()}.mp3`;
      let audioBuffer = null;

      // API 1: Vreden TTS
      try {
        const res = await fetch(
          `https://api.vreden.web.id/api/tts?text=${encodeURIComponent(text)}&lang=${lang}`,
          { timeout: 12000 }
        );
        if (res.ok) {
          const buf = Buffer.from(await res.arrayBuffer());
          if (buf.length > 500) audioBuffer = buf;
        }
      } catch {}

      // API 2: Google TTS
      if (!audioBuffer) {
        try {
          const res = await fetch(
            `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${lang}&q=${encodeURIComponent(text)}`,
            { headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 12000 }
          );
          if (res.ok) {
            const buf = Buffer.from(await res.arrayBuffer());
            if (buf.length > 500) audioBuffer = buf;
          }
        } catch {}
      }

      // API 3: Delirius TTS
      if (!audioBuffer) {
        try {
          const res = await fetch(
            `https://api.delirius.store/other/tts?text=${encodeURIComponent(text)}&lang=${lang}`,
            { timeout: 12000 }
          );
          if (res.ok) {
            const buf = Buffer.from(await res.arrayBuffer());
            if (buf.length > 500) audioBuffer = buf;
          }
        } catch {}
      }

      // API 4: StreamElements TTS (fallback global)
      if (!audioBuffer) {
        try {
          const voice = lang === 'pt' ? 'Vitoria' : lang === 'en' ? 'Brian' : lang === 'es' ? 'Miguel' : lang === 'fr' ? 'Mathieu' : 'Brian';
          const res = await fetch(
            `https://api.streamelements.com/kappa/v2/speech?voice=${voice}&text=${encodeURIComponent(text)}`,
            { timeout: 12000 }
          );
          if (res.ok) {
            const buf = Buffer.from(await res.arrayBuffer());
            if (buf.length > 500) audioBuffer = buf;
          }
        } catch {}
      }

      if (!audioBuffer) {
        return msg.reply(`❌ Não foi possível gerar o áudio. Tenta com texto mais curto ou outro idioma.`);
      }

      fs.writeFileSync(tmpFile, audioBuffer);
      await sock.sendMessage(msg.chat, {
        audio: { url: tmpFile },
        mimetype: 'audio/mpeg',
        ptt: true
      }, { quoted: msg });
      await msg.react('✅');

      setTimeout(() => { try { if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile); } catch {} }, 10000);
    } catch (e) {
      await msg.react('❌');
      await msg.reply(`❌ Erro ao gerar voz: ${e.message}`);
    }
  }
};
