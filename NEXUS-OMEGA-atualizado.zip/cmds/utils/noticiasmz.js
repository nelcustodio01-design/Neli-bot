/**
 * 📰 NOTÍCIAS DE MOÇAMBIQUE — Corrigido: usa APIs públicas funcionais
 */
import fetch from 'node-fetch';

export default {
  command: ['noticiasmz', 'mznews', 'moznews', 'jornalmz'],
  category: 'utilidades',
  description: 'Mostra as últimas notícias de Moçambique 🇲🇿',
  run: async ({ msg, sock, usedPrefix, command }) => {
    await msg.react('📰');
    try {
      let noticias = [];

      // API 1: GNews (gratuita, sem key para PT)
      try {
        const res = await fetch(
          `https://gnews.io/api/v4/search?q=Moçambique&lang=pt&country=mz&max=6&token=free`,
          { timeout: 10000 }
        );
        const data = await res.json();
        if (data?.articles?.length) {
          noticias = data.articles.map(a => ({ title: a.title, desc: a.description, url: a.url, source: a.source?.name }));
        }
      } catch {}

      // API 2: Vreden Google Search
      if (!noticias.length) {
        try {
          const res = await fetch(
            `https://api.vreden.web.id/api/search/google?query=ultimas+noticias+Mocambique+hoje`,
            { timeout: 10000 }
          );
          const data = await res.json();
          const results = data?.result || data?.results || [];
          if (results.length) {
            noticias = results.slice(0, 6).map(n => ({
              title: n.title,
              desc: n.snippet || n.description || '',
              url: n.link || n.url,
              source: n.source || 'Web'
            }));
          }
        } catch {}
      }

      // API 3: Siputzx Google Search
      if (!noticias.length) {
        try {
          const res = await fetch(
            `https://api.siputzx.my.id/api/search/google?query=noticias+Mocambique+hoje&num=6`,
            { timeout: 10000 }
          );
          const data = await res.json();
          const results = data?.data || data?.result || [];
          if (results.length) {
            noticias = results.slice(0, 6).map(n => ({
              title: n.title,
              desc: n.snippet || n.description || '',
              url: n.link || n.url,
              source: 'Web'
            }));
          }
        } catch {}
      }

      if (!noticias.length) {
        return msg.reply('❌ Não consegui obter notícias de Moçambique neste momento. Tenta mais tarde.');
      }

      let texto = `🇲🇿 *ÚLTIMAS NOTÍCIAS DE MOÇAMBIQUE*\n`;
      texto += `━━━━━━━━━━━━━━━━━━━━\n\n`;

      noticias.forEach((n, i) => {
        texto += `${i + 1}. 📰 *${n.title || 'Sem título'}*\n`;
        if (n.desc) texto += `   💬 ${n.desc.substring(0, 120)}${n.desc.length > 120 ? '...' : ''}\n`;
        if (n.source) texto += `   📡 ${n.source}\n`;
        if (n.url) texto += `   🔗 ${n.url}\n`;
        texto += '\n';
      });

      texto += `> 🇲🇿 _Nel-Aviso-Bot-Moz — Nexus Singularity V14_`;

      await msg.reply(texto.trim());
      await msg.react('✅');
    } catch (e) {
      console.error(e);
      await msg.react('❌');
      await msg.reply(`❌ Erro ao obter notícias: ${e.message}`);
    }
  }
};
