export default {
  command: ['task','agendar'],
  category: 'utils',
  description: 'Agenda uma tarefa ou lembrete inteligente.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args[0] || !args[1]) return msg.reply(`⏳ **NEXUS TASK: AUTOMAÇÃO**\n\nUso: *${usedPrefix + command} [tempo em min] [tarefa]*\nExemplo: *${usedPrefix + command} 10 Beber água e verificar o bot.*`);

    const timeMin = parseInt(args[0]);
    const task = args.slice(1).join(' ');

    if (isNaN(timeMin)) return msg.reply('❌ Por favor, insira um tempo válido em minutos.');

    await msg.react('⏳');
    await msg.reply(`✅ **TAREFA AGENDADA:** Vou lembrar você de "${task}" em ${timeMin} minutos.`);

    setTimeout(async () => {
        const reminder = `
🔔 **NEXUS TASK: LEMBRETE ATIVO**
━━━━━━━━━━━━━━━━━━━━━━

Olá! Você pediu para ser lembrado agora:
> *${task}*

🚀 *Automação Nexus Singularity operacional.*
        `;
        await sock.sendMessage(msg.chat, { text: reminder }, { quoted: msg });
    }, timeMin * 60 * 1000);
  }
};
