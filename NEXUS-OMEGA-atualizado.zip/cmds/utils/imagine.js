/**
 * 🎨 IMAGINE — Gerador de imagens por IA
 * Corrigido: API, contexto e fallbacks robustos
 */
import fetch from 'node-fetch';

export default {
  command: ['imagine'],
  category: 'ia',
  description: 'Gera imagens com IA a partir de uma descrição 🎨',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const prompt = args.join(' ').trim();
    if (!prompt) {
      return msg.reply(
        `🎨 *GERADOR DE IMAGENS IA*\n\n` +
        `Uso: *${usedPrefix}${command} [descrição da imagem]*\n\n` +
        `Exemplos:\n` +
        `▸ *${usedPrefix}${command} leão tecnológico em Moçambique cyberpunk*\n` +
        `▸ *${usedPrefix}${command} praia tropical ao pôr do sol*\n` +
        `▸ *${usedPrefix}${command} robô a dançar na lua, estilo anime*\n\n` +
        `💡 Quanto mais detalhado, melhor o resultado!`
      );
    }
    if (prompt.length > 500) return msg.reply('❌ Descrição muito longa! Máximo 500 caracteres.');

    const { key } = await sock.sendMessage(msg.chat, {
      text: `🎨 *Gerando imagem...*\n▸ Prompt: _${prompt}_\n⏳ Aguarde...`
    }, { quoted: msg });
    await msg.react('🎨');

    let imageUrl = null;

    // 1. Pollinations AI (gratuito, sem API key - muito estável)
    try {
      imageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=1024&nologo=true&seed=${Date.now()}`;
      const testRes = await fetch(imageUrl, { method: 'HEAD', timeout: 12000 });
      if (!testRes.ok) imageUrl = null;
    } catch { imageUrl = null; }

    // 2. API siputzx
    if (!imageUrl) {
      try {
        const res = await fetch(`https://api.siputzx.my.id/api/s/text2img?prompt=${encodeURIComponent(prompt)}`, { timeout: 15000 });
        const json = await res.json();
        if (json?.status && json?.data) imageUrl = typeof json.data === 'string' ? json.data : (json.data.url || json.data.image);
      } catch {}
    }

    // 3. API delirius
    if (!imageUrl) {
      try {
        const res = await fetch(`${global.APIs.delirius.url}/ia/dalle?text=${encodeURIComponent(prompt)}`, { timeout: 15000 });
        const json = await res.json();
        if (json?.status && json?.data) imageUrl = typeof json.data === 'string' ? json.data : (json.data.url || json.data.image);
      } catch {}
    }

    // 4. API yuki
    if (!imageUrl) {
      try {
        const res = await fetch(`${global.APIs.yuki.url}/ai/dalle?text=${encodeURIComponent(prompt)}&key=${global.APIs.yuki.key}`, { timeout: 15000 });
        const json = await res.json();
        if (json?.status && json?.result) imageUrl = typeof json.result === 'string' ? json.result : (json.result.url || json.result.image);
      } catch {}
    }

    // 5. API vreden
    if (!imageUrl) {
      try {
        const res = await fetch(`${global.APIs.vreden.url}/api/ai/dalle3?query=${encodeURIComponent(prompt)}`, { timeout: 15000 });
        const json = await res.json();
        if (json?.result) imageUrl = typeof json.result === 'string' ? json.result : (json.result.url || json.result.image);
      } catch {}
    }

    if (!imageUrl) {
      return sock.sendMessage(msg.chat, {
        text: '❌ Não foi possível gerar a imagem agora. Tenta novamente com outro prompt.', edit: key
      }, { quoted: msg });
    }

    await sock.sendMessage(msg.chat, {
      image: { url: imageUrl },
      caption: `🎨 *Imagem Gerada com IA*\n\n▸ Prompt: _${prompt}_\n\n💡 Use *${usedPrefix}gerarimg <prompt>* para criar mais!`
    }, { quoted: msg });
    await msg.react('✅');
  }
};
