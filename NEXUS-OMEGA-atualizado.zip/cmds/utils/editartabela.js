import {
  DEFAULT_PACKAGE_CATALOG,
  formatPackageSize,
  getPackageCatalog,
  savePackageCatalog,
} from '../../core/businessCatalog.js';

const PERIODS = {
  daily: 'daily', diario: 'daily', diaria: 'daily', diário: 'daily', diária: 'daily', dia: 'daily',
  monthly: 'monthly', mensal: 'monthly', mensalmente: 'monthly', mes: 'monthly', mês: 'monthly',
};

function renderCatalog(catalog) {
  const section = (title, rows) => [
    `*${title}*`,
    ...(rows.length ? rows.map(item => `• *${item.price} MT* → ${formatPackageSize(item.mb)}`) : ['(sem pacotes)']),
  ].join('\n');
  return `${section('PACOTES DIÁRIOS (24H)', catalog.daily)}\n\n${section('PACOTES MENSAIS (30 DIAS)', catalog.monthly)}`;
}

export default {
  command: ['editartabela', 'tabelaeditar', 'setpacotes'],
  category: 'pagamentos',
  description: 'Editar a tabela de pacotes sem sair do WhatsApp.',
  ownerOnly: true,
  run: async ({ msg, args, usedPrefix, command }) => {
    const usage = [
      `Uso:`,
      `• *${usedPrefix + command} add diario <preço-MT> <quantidade> <MB|GB>*`,
      `• *${usedPrefix + command} add mensal <preço-MT> <quantidade> <MB|GB>*`,
      `• *${usedPrefix + command} remove <preço-MT>*`,
      `• *${usedPrefix + command} reset*`,
      `• *${usedPrefix + command} listar*`,
      `Exemplo: *${usedPrefix + command} add diario 12 500 MB*`,
    ].join('\n');
    const action = (args[0] || 'listar').toLowerCase();
    const catalog = getPackageCatalog();

    if (['listar', 'list', 'ver'].includes(action)) {
      return msg.reply(`${renderCatalog(catalog)}\n\n${usage}`);
    }
    if (action === 'reset') {
      savePackageCatalog(structuredClone(DEFAULT_PACKAGE_CATALOG));
      return msg.reply(`Tabela reposta para os valores originais.\n\n${renderCatalog(getPackageCatalog())}`);
    }
    if (['remove', 'remover', 'del', 'delete'].includes(action)) {
      const price = Number(args[1]);
      if (!Number.isFinite(price) || price <= 0) return msg.reply(usage);
      let removed = 0;
      for (const period of ['daily', 'monthly']) {
        const before = catalog[period].length;
        catalog[period] = catalog[period].filter(item => item.price !== price);
        removed += before - catalog[period].length;
      }
      if (!removed) return msg.reply(`Não encontrei um pacote de *${price} MT*.`);
      savePackageCatalog(catalog);
      return msg.reply(`Pacote de *${price} MT* removido.\n\n${renderCatalog(catalog)}`);
    }
    if (action === 'add' || action === 'adicionar') {
      const period = PERIODS[(args[1] || '').toLowerCase()];
      const price = Number(args[2]);
      const quantity = Number(args[3]);
      const unit = (args[4] || 'MB').toLowerCase();
      const multiplier = ['gb', 'g', 'gbps'].includes(unit) ? 1024 : ['mb', 'm'].includes(unit) ? 1 : 0;
      if (!period || !Number.isFinite(price) || price <= 0
        || !Number.isFinite(quantity) || quantity <= 0 || !multiplier) {
        return msg.reply(usage);
      }
      const mb = Math.round(quantity * multiplier);
      const existing = catalog[period].find(item => item.price === price);
      if (existing) existing.mb = mb;
      else catalog[period].push({ price, mb });
      catalog[period].sort((a, b) => a.price - b.price);
      savePackageCatalog(catalog);
      return msg.reply(`Pacote ${period === 'daily' ? 'diário' : 'mensal'} atualizado: *${price} MT* → *${formatPackageSize(mb)}*.\n\n${renderCatalog(catalog)}`);
    }
    return msg.reply(usage);
  },
};
