/**
 * 🌍🎙️ TRADUTOR VOCAL — Traduz e gera áudio da tradução
 * Corrigido: comandos únicos, APIs funcionais
 */
import fetch from 'node-fetch';
import fs from 'fs';

export default {
  command: ['tradvoz', 'traduzirsom', 'vocaltrad', 'tradaudio'],
  category: 'utilidades',
  description: 'Traduz texto e envia a tradução em áudio 🌍🔊',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    if (!args[0]) {
      return msg.reply(
        `🌍🔊 *TRADUTOR VOCAL*\n\n` +
        `Traduz o texto e envia em áudio!\n\n` +
        `Uso: *${usedPrefix}${command} [idioma] [texto]*\n\n` +
        `Exemplos:\n` +
        `▸ *${usedPrefix}${command} en Bom dia Moçambique!*\n` +
        `▸ *${usedPrefix}${command} es Como estás?*\n` +
        `▸ *${usedPrefix}${command} fr Bonjour le monde*\n\n` +
        `Idiomas: pt, en, es, fr, de, it, ja, zh, ru, ar`
      );
    }

    const targetLang = args[0].toLowerCase();
    const text = args.slice(1).join(' ').trim();

    if (!text) return msg.reply('❌ Escreve o texto que queres traduzir e ouvir!');

    await msg.react('🌍');

    try {
      let translated = null;

      // Traduzir: Delirius
      try {
        const res = await fetch(`https://api.delirius.store/other/translate?text=${encodeURIComponent(text)}&to=${targetLang}`, { timeout: 10000 });
        const data = await res.json();
        if (data?.status && data?.result) {
          translated = data.result.translated || data.result.text || (typeof data.result === 'string' ? data.result : null);
        }
      } catch {}

      // Traduzir: MyMemory (fallback)
      if (!translated) {
        try {
          const res = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=auto|${targetLang}`, { timeout: 10000 });
          const data = await res.json();
          if (data?.responseData?.translatedText) translated = data.responseData.translatedText;
        } catch {}
      }

      // Traduzir: Vreden (fallback)
      if (!translated) {
        try {
          const res = await fetch(`https://api.vreden.web.id/api/tools/translate?text=${encodeURIComponent(text)}&to=${targetLang}`, { timeout: 10000 });
          const data = await res.json();
          if (data?.result) translated = data.result;
        } catch {}
      }

      if (!translated) return msg.reply('❌ Não foi possível traduzir o texto. Tenta novamente.');

      // Enviar texto traduzido
      await msg.reply(
        `🌍 *TRADUÇÃO VOCAL*\n\n` +
        `📝 Original: _${text}_\n` +
        `✅ ${targetLang.toUpperCase()}: _${translated}_`
      );

      // Gerar e enviar áudio da tradução
      try {
        if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp', { recursive: true });
        const tmpFile = `./tmp/tradvoz_${Date.now()}.mp3`;
        let audioBuffer = null;

        // API 1: Vreden TTS
        try {
          const res = await fetch(`https://api.vreden.web.id/api/tts?text=${encodeURIComponent(translated)}&lang=${targetLang}`, { timeout: 12000 });
          if (res.ok) {
            const buf = Buffer.from(await res.arrayBuffer());
            if (buf.length > 500) audioBuffer = buf;
          }
        } catch {}

        // API 2: Google TTS
        if (!audioBuffer) {
          try {
            const res = await fetch(
              `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${targetLang}&q=${encodeURIComponent(translated)}`,
              { headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 12000 }
            );
            if (res.ok) {
              const buf = Buffer.from(await res.arrayBuffer());
              if (buf.length > 500) audioBuffer = buf;
            }
          } catch {}
        }

        if (audioBuffer) {
          fs.writeFileSync(tmpFile, audioBuffer);
          await sock.sendMessage(msg.chat, {
            audio: { url: tmpFile },
            mimetype: 'audio/mpeg',
            ptt: true
          }, { quoted: msg });
          setTimeout(() => { try { if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile); } catch {} }, 10000);
        }
      } catch {}

      await msg.react('✅');
    } catch (e) {
      await msg.react('❌');
      await msg.reply(`❌ Erro: ${e.message}`);
    }
  }
};
