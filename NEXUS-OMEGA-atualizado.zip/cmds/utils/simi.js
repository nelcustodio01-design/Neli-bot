// ╔══════════════════════════════════════════════════════════════╗
//   NEL-AVISO-BOT-MOZ · cmds/utils/simi.js
//   SimSimi — AI chatbot com respostas engraçadas/simuladas
// ╚══════════════════════════════════════════════════════════════╝

export default {
  command: ['simi', 'sim', 'simsimi', 'simchat', 'botchat'],
  description: 'Conversa com o SimSimi — respostas engraçadas e provocantes',
  category: 'ia',
  usage: '.simi <mensagem>',
  example: '.simi Olá como estás?',
  run: async function (msg, sock, args, text, usedPrefix, command, isOwner, isGroup, from, sender) {
    const texto = args.join(' ').trim();
    if (!texto) {
      return sock.sendMessage(from, {
        text: '❌ Escreve algo para o SimSimi responder!\n\n💡 *Uso:* .simi <mensagem>\n📌 *Ex:* .simi Olá como estás?'
      }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '🤖', key: msg.key } });

    try {
      const res = await fetch(`https://api.delirius.store/ia/simismi?text=${encodeURIComponent(texto)}`);
      const data = await res.json();

      if (data?.status === 200 && data?.result) {
        const response = data.result;
        await sock.sendMessage(from, {
          text: `🤖 *SimSimi:*\n\n${response}`,
          contextInfo: {
            externalAdReply: {
              title: 'SimSimi AI',
              body: 'Conversa engraçada',
              thumbnailUrl: 'https://cdn-icons-png.flaticon.com/512/4733/4733089.png',
              mediaType: 1
            }
          }
        }, { quoted: msg });
        return;
      }
    } catch (e) {
      console.log('SimSimi primary failed:', e.message);
    }

    try {
      const res = await fetch(`https://api.delirius.store/ia/chatgpt?prompt=${encodeURIComponent('Responde como se fosses o SimSimi, um bot de chat engraçado, provocante e às vezes mal-educado. Responde de forma curta, engraçada e em português. Mensagem do utilizador: ' + texto)}`);
      const data = await res.json();

      if (data?.status === 200 && data?.result) {
        await sock.sendMessage(from, {
          text: `🤖 *SimSimi:*\n\n${data.result}`,
          contextInfo: {
            externalAdReply: {
              title: 'SimSimi AI',
              body: 'Conversa engraçada',
              thumbnailUrl: 'https://cdn-icons-png.flaticon.com/512/4733/4733089.png',
              mediaType: 1
            }
          }
        }, { quoted: msg });
        return;
      }
    } catch (e) {
      console.log('SimSimi fallback failed:', e.message);
    }

    const respostas = [
      'Hmm, não sei o que dizer 😅',
      'Haha, isso foi engraçado! 🤣',
      'Tu és mesmo estranho 😂',
      'Ah é? Pois pois... 🙄',
      'Não entendi nada! 💀',
      'Sai daí com isso! 😤',
      'OLÁ! Eu sou o SimSimi e tu és chato 😜',
      'Talvez... quem sabe? 🤷',
      'Isso é segredo! 🤫',
      'Vai perguntar à tua avó! 👵😂'
    ];
    const random = respostas[Math.floor(Math.random() * respostas.length)];
    await sock.sendMessage(from, {
      text: `🤖 *SimSimi:*\n\n${random}\n\n_⚠️ Modo offline — API indisponível_`
    }, { quoted: msg });
  }
};
