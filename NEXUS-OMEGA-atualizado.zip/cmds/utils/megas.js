import { formatPackageSize, getPackageCatalog } from '../../core/businessCatalog.js';

export default {
  command: ['megas', 'tabela', 'net', 'tabelanet', 'pacotes'],
  category: 'utilidades',
  description: 'Ver a tabela de pacotes de internet NEL NET Express',
  customPrefix: /^(megas|net|tabela|tabelanet|pacotes)$/i,
  run: async ({ msg, usedPrefix }) => {
    const catalog = getPackageCatalog();
    const daily = catalog.daily.map(item => `*${item.price} MT* → *${formatPackageSize(item.mb)}*`).join('\n') || '(sem pacotes configurados)';
    const monthly = catalog.monthly.map(item => `*${item.price} MT* → *${formatPackageSize(item.mb)}*`).join('\n') || '(sem pacotes configurados)';
    return msg.reply(`*NEL NET EXPRESS — PACOTES DE INTERNET*\n🛜 Ativação mediante confirmação do pagamento\n\n*📍 PACOTES DIÁRIOS (24H)*\n${daily}\n\n*📅 PACOTES MENSAIS (30 DIAS)*\n${monthly}\n\nPara ver as formas de pagamento digite: *${usedPrefix}pagamento*\n\nNEL NET Express — Navega sem limites.`);
  },
};
