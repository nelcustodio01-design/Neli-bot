import axios from 'axios';

export default {
  command: ['v'],
  category: 'downloads',
  description: 'Procura e descarrega um vídeo pelo nome.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const query = args.join(' ');
    if (!query) return msg.reply(`🎬 **NEXUS VIDEO SEARCH**\n\nUso: *${usedPrefix + command} [nome do vídeo]*\nExemplo: *${usedPrefix + command} Nel Custódio Inovação*`);

    await msg.react('🎬');
    await msg.reply(`🎬 **NEXUS ENGINE:** Localizando "${query}" nos servidores de alta velocidade...`);

    try {
      // 1. Buscar o vídeo (usando API de busca de vídeo real)
      const searchUrl = `https://api.vreden.web.id/api/search/youtube?query=${encodeURIComponent(query)}`;
      const searchRes = await axios.get(searchUrl);
      const video = searchRes.data?.result?.[0];

      if (!video) return msg.reply('❌ Nenhum vídeo encontrado com este nome.');

      const videoUrl = video.url;
      await msg.reply(`📥 **VÍDEO ENCONTRADO:**\n\n> *Título:* ${video.title}\n> *Duração:* ${video.duration}\n\n*Iniciando conversão e envio...*`);

      // 2. Descarregar o vídeo (usando motor de download universal)
      const downloadUrl = `https://api.vreden.web.id/api/download/ytmp4?url=${encodeURIComponent(videoUrl)}`;
      const downloadRes = await axios.get(downloadUrl);
      const dlLink = downloadRes.data?.result?.download?.url || downloadRes.data?.result?.url;

      if (!dlLink) throw new Error('Download link not found');

      await sock.sendMessage(msg.chat, { 
        video: { url: dlLink }, 
        caption: `🎬 **${video.title}**\n\n🚀 *Baixado via Nexus Singularity V14*`,
        mimetype: 'video/mp4'
      }, { quoted: msg });

      await msg.react('✅');
    } catch (e) {
      console.error('Video Download Error:', e);
      msg.reply('❌ Falha ao processar o vídeo. O servidor de extração pode estar instável.');
    }
  }
};
