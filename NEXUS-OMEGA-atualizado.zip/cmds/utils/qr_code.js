/**
 * .qr-code - Gerador de QR Code
 * Cria QR codes escaneáveis para URLs, texto e WiFi
 * Uso: .qr [texto/URL]
 */

import QRCode from 'qrcode';
import { writeFileSync } from 'fs';
import { join } from 'path';
import { randomBytes } from 'crypto';

export default {
  command: ['qr-adv', 'qr-expert', 'qrcode-ia'],
  category: 'utils',
  description: 'Gera QR codes escaneáveis',
  usage: '.qr [texto/URL]',
  run: async function (msg, sock, args, text, usedPrefix, command) {
    try {
      if (!args.length) {
        return msg.reply(
          '📱 *Gerador de QR Code*\n\n' +
          'Uso: `.qr [texto/URL]`\n\n' +
          'Exemplos:\n' +
          '• `.qr https://seu-site.com`\n' +
          '• `.qr https://wa.me/258878464656`\n' +
          '• `.qr Olá, este é um QR code!`\n' +
          '• `.qr WIFI:T:WPA;S:NomeDaRede;P:Senha;;`'
        );
      }

      const dados = args.join(' ');

      if (dados.length > 2953) {
        return msg.reply('❌ Texto muito longo para QR code! Máximo 2953 caracteres.');
      }

      const processing = await msg.reply(
        '⏳ Gerando QR code...\n' +
        `Dados: ${dados.substring(0, 50)}${dados.length > 50 ? '...' : ''}\n\n` +
        'Por favor, aguarde...'
      );

      try {
        const qrPath = await gerarQRCode(dados);

        if (!qrPath) {
          return msg.reply('❌ Erro ao gerar QR code!');
        }

        let tipo = 'Texto';
        if (dados.startsWith('http://') || dados.startsWith('https://')) {
          tipo = 'URL';
        } else if (dados.startsWith('WIFI:')) {
          tipo = 'WiFi';
        } else if (dados.startsWith('mailto:')) {
          tipo = 'Email';
        } else if (dados.startsWith('tel:') || dados.startsWith('+')) {
          tipo = 'Telefone';
        }

        await sock.sendMessage(msg.chat, {
          image: { url: `file://${qrPath}` },
          caption:
            `✅ *QR Code Gerado com Sucesso!*\n\n` +
            `📱 *Tipo:* ${tipo}\n` +
            `📊 *Dados:* ${dados.substring(0, 50)}${dados.length > 50 ? '...' : ''}\n` +
            `📈 *Caracteres:* ${dados.length}\n` +
            `🔍 *Versão:* Auto-detectada\n` +
            `⏰ ${new Date().toLocaleTimeString('pt-MZ')}\n\n` +
            `💡 Dica: Escaneie com a câmera do seu telefone!`
        }, { quoted: msg });

        await sock.sendMessage(msg.chat, { delete: processing.key });

      } catch (error) {
        console.error('Erro ao gerar QR:', error);
        return msg.reply('❌ Erro ao processar QR code!');
      }

    } catch (error) {
      console.error('Erro em qr_code:', error);
      msg.reply('❌ Erro ao processar comando qr!');
    }
  }
};

async function gerarQRCode(dados) {
  try {
    const fileName = `qr_${randomBytes(4).toString('hex')}.png`;
    const filePath = join(process.cwd(), 'temp', fileName);

    await QRCode.toFile(filePath, dados, {
      errorCorrectionLevel: 'H',
      type: 'image/png',
      quality: 0.95,
      margin: 2,
      width: 300,
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      }
    });

    return filePath;

  } catch (error) {
    console.error('Erro ao criar QR code:', error);
    return null;
  }
}

export function gerarWiFiQR(ssid, senha, tipo = 'WPA') {
  return `WIFI:T:${tipo};S:${ssid};P:${senha};;`;
}

export function gerarWhatsAppQR(numero) {
  return `https://wa.me/${numero}`;
}

export function gerarEmailQR(email, assunto = '', corpo = '') {
  let url = `mailto:${email}`;
  const params = [];
  if (assunto) params.push(`subject=${encodeURIComponent(assunto)}`);
  if (corpo) params.push(`body=${encodeURIComponent(corpo)}`);
  if (params.length > 0) {
    url += '?' + params.join('&');
  }
  return url;
}
