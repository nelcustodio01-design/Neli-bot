export default {
  name: "mocambique",
  alias: ["moz", "moçambique", "info_moz"],
  desc: "Informações sobre Moçambique",
  category: "utils",
  react: "🇲🇿",
  isGroup: false,
  isBotAdminRequired: false,
  isAdminRequired: false,
  run: async ({ sock, msg, usedPrefix }) => {
    const info = `
╔════════════════════════════════════════╗
║        🇲🇿 MOÇAMBIQUE 🇲🇿              ║
║    Informações Gerais do País          ║
╚════════════════════════════════════════╝

📍 *INFORMAÇÕES GERAIS*
Capital: Maputo
População: ~33 milhões
Idioma: Português
Moeda: Metical (MZN)
Fuso Horário: UTC+2

🗺️ *PROVÍNCIAS* (11)
1. Maputo (Cidade)
2. Maputo (Província)
3. Gaza
4. Inhambane
5. Sofala
6. Manica
7. Tete
8. Zambézia
9. Nampula
10. Cabo Delgado
11. Niassa

🏥 *NÚMEROS DE EMERGÊNCIA*
🚑 Ambulância: 117 ou 1194
🚒 Bombeiros: 119 ou 1194
🚔 Polícia: 113 ou 1194
☎️ Informações: 1194

💰 *INFORMAÇÕES FINANCEIRAS*
Moeda: Metical (MZN)
Banco Central: BdM
Bancos Principais:
  • BIM (Banco de Investimento de Moçambique)
  • BCI (Banco Comercial de Investimentos)
  • Standard Bank
  • Millennium BIM

📱 *OPERADORAS DE TELECOMUNICAÇÕES*
Vodacom: +258 82/83
Movitel: +258 84/85
Tmcel: +258 86/87

✈️ *TRANSPORTES*
Aeroporto Principal: Maputo (AICM)
Companhias Aéreas:
  • LAM (Linhas Aéreas de Moçambique)
  • TAAG (Angola Airlines)
  • Ethiopian Airlines

🏨 *CIDADES PRINCIPAIS*
1. Maputo - Capital
2. Beira - Cidade portuária
3. Nampula - Centro comercial
4. Chimoio - Cidade histórica
5. Inhambane - Turismo

🎓 *EDUCAÇÃO*
Universidades Principais:
  • Universidade Eduardo Mondlane (UEM)
  • Universidade Católica de Moçambique
  • Universidade Técnica de Moçambique

⚽ *DESPORTO*
Futebol: Desporto nacional
Seleção: "Mambas"
Liga: Moçambola
Estádio: Estádio Nacional

🎭 *CULTURA*
Dança: Timbila, Xigubo
Música: Marrabenta, Kwaito
Artesanato: Máscaras, Esculturas

🍽️ *GASTRONOMIA*
Pratos Típicos:
  • Peri-Peri (frango picante)
  • Arroz de Marisco
  • Matapa (folhas com amendoim)
  • Ximango (milho ralado)

🌴 *TURISMO*
Praias Famosas:
  • Inhambane
  • Vilanculos
  • Bazaruto
  • Tofo

🌍 *CLIMA*
Estação Quente: Outubro a Março
Estação Fria: Abril a Setembro
Temperatura Média: 20-30°C

📚 *HISTÓRIA*
Independência: 25 de Junho de 1975
Primeira Presidente: Samora Machel
Atual Presidente: Filipe Nyusi (até 2024)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Para mais informações, use:
${prefix}provincias - Detalhes sobre províncias
${prefix}cambio - Taxa de câmbio
${prefix}emergencia - Números de emergência
${prefix}farmacias - Farmácias de serviço
${prefix}hospitais - Hospitais próximos
${prefix}transportes - Informações de transportes
${prefix}clima - Previsão do tempo

╔════════════════════════════════════════╗
║  Desenvolvido para Moçambique 🇲🇿     ║
╚════════════════════════════════════════╝
    `;

    try {
      await sock.sendMessage(msg.chat, {
        text: info,
      }, { quoted: msg });
    } catch (error) {
      console.error("Erro:", error);
    }
  },
};
