/**
 * Redirecionado para noticias_realtime.js
 * Este ficheiro está desativado para evitar conflito de comandos
 */
export default {
  command: ['_noticias_old'],
  category: 'utilidades',
  description: 'Desativado (ver noticias_realtime.js)',
  run: async ({ msg }) => {}
};
