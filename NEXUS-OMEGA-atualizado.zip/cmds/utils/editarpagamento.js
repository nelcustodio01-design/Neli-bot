import db from '#db';

const METHODS = {
  mpesa: 'mpesa', 'm-pesa': 'mpesa',
  emola: 'emola', 'e-mola': 'emola',
};

function getMethods() {
  return db.getBusinessConfig('paymentMethods', global.contasDono || { mpesa: {}, emola: {}, outros: '' });
}

export default {
  command: ['editarpagamento', 'setpagamento', 'pagamentoeditar'],
  category: 'pagamentos',
  description: 'Editar os dados de pagamento mostrados pelo bot.',
  ownerOnly: true,
  run: async ({ msg, args, usedPrefix, command }) => {
    const usage = [
      `Uso:`,
      `• *${usedPrefix + command} mpesa <número> | <titular>*`,
      `• *${usedPrefix + command} emola <número> | <titular>*`,
      `• *${usedPrefix + command} outros <instruções>*`,
      `• *${usedPrefix + command} limpar mpesa|emola|outros*`,
      `• *${usedPrefix + command} listar*`,
    ].join('\n');
    const action = (args[0] || 'listar').toLowerCase();
    const config = getMethods();

    if (['listar', 'list', 'ver'].includes(action)) {
      const mpesa = config.mpesa || {};
      const emola = config.emola || {};
      return msg.reply(`*Dados de pagamento configurados*\nM-Pesa: ${mpesa.numero ? `${mpesa.numero}${mpesa.nome ? ` — ${mpesa.nome}` : ''}` : 'não configurado'}\nE-Mola: ${emola.numero ? `${emola.numero}${emola.nome ? ` — ${emola.nome}` : ''}` : 'não configurado'}\nOutros: ${config.outros || 'não configurado'}\n\n${usage}`);
    }
    if (['limpar', 'clear', 'remover'].includes(action)) {
      const method = (args[1] || '').toLowerCase();
      if (METHODS[method]) config[METHODS[method]] = {};
      else if (method === 'outros' || method === 'other') config.outros = '';
      else return msg.reply(usage);
      db.setBusinessConfig('paymentMethods', config);
      return msg.reply(`Dados de pagamento *${method}* removidos.`);
    }
    if (action === 'outros' || action === 'other') {
      const text = args.slice(1).join(' ').trim();
      if (!text) return msg.reply(usage);
      config.outros = text;
      db.setBusinessConfig('paymentMethods', config);
      return msg.reply('Instruções adicionais de pagamento atualizadas.');
    }

    const method = METHODS[action];
    if (!method) return msg.reply(usage);
    const value = args.slice(1).join(' ');
    const [number, ...holderParts] = value.split('|');
    const numero = (number || '').trim().replace(/[^\d+]/g, '');
    const nome = holderParts.join('|').trim();
    if (!/^\+?\d{9,15}$/.test(numero) || !nome) return msg.reply(usage);
    config[method] = { numero, nome };
    db.setBusinessConfig('paymentMethods', config);
    return msg.reply(`${method === 'mpesa' ? 'M-Pesa' : 'E-Mola'} atualizado: *${numero}* — *${nome}*.`);
  },
};
