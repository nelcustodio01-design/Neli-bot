/**
 * 🎙️ VOZ — Converte texto em voz (nota de voz PTT)
 * Corrigido: usa APIs robustas com múltiplos fallbacks
 */
import fetch from 'node-fetch';
import fs from 'fs';
import generateMaleSpeech from '../../core/maleTts.js';

export default {
  command: ['voz','vozbot'],
  category: 'utilidades',
  description: 'Converte texto em nota de voz 🎙️',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    let text = args.join(' ').trim();
    if (!text && msg.quoted) {
      text = msg.quoted.text || msg.quoted.body || msg.quoted.caption || '';
    }
    if (!text) return msg.reply(`🎙️ *NEXUS VOICE ENGINE*\n\nUso: *${usedPrefix}${command} [texto]*\nEx: *${usedPrefix}${command} Olá, tudo bem?*\n\nOu responde a uma mensagem com *${usedPrefix}${command}*`);
    if (text.length > 500) text = text.substring(0, 500);

    await msg.react('🎙️');

    try {
      if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp', { recursive: true });
      const tmpFile = `./tmp/voz_${Date.now()}.mp3`;
      let audioBuffer = null;

      // Motor principal: voz masculina explícita em português.
      audioBuffer = await generateMaleSpeech(text);

      // API 1: Vreden TTS (fallback compatível com PT)
      if (!audioBuffer) try {
        const res = await fetch(`https://api.vreden.web.id/api/tts?text=${encodeURIComponent(text)}&lang=pt`, { timeout: 12000 });
        if (res.ok) {
          const buf = Buffer.from(await res.arrayBuffer());
          if (buf.length > 500) audioBuffer = buf;
        }
      } catch {}

      // API 2: Google TTS
      if (!audioBuffer) {
        try {
          const res = await fetch(
            `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=pt&q=${encodeURIComponent(text)}`,
            { headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 12000 }
          );
          if (res.ok) {
            const buf = Buffer.from(await res.arrayBuffer());
            if (buf.length > 500) audioBuffer = buf;
          }
        } catch {}
      }

      // API 3: Delirius TTS
      if (!audioBuffer) {
        try {
          const res = await fetch(`https://api.delirius.store/other/tts?text=${encodeURIComponent(text)}&lang=pt`, { timeout: 12000 });
          if (res.ok) {
            const buf = Buffer.from(await res.arrayBuffer());
            if (buf.length > 500) audioBuffer = buf;
          }
        } catch {}
      }

      if (!audioBuffer) {
        return msg.reply('❌ Não foi possível gerar o áudio. Tenta novamente.');
      }

      fs.writeFileSync(tmpFile, audioBuffer);
      await sock.sendMessage(msg.chat, {
        audio: { url: tmpFile },
        mimetype: 'audio/ogg; codecs=opus',
        ptt: true
      }, { quoted: msg });
      await msg.react('✅');

      setTimeout(() => { try { if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile); } catch {} }, 10000);
    } catch (e) {
      await msg.react('❌');
      await msg.reply(`❌ Erro ao gerar voz: ${e.message}`);
    }
  }
};
