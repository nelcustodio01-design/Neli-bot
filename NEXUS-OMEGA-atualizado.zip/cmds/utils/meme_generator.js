/**
 * .meme-generator - Gerador de Memes
 * Cria memes com templates populares
 * Uso: .meme [template] [texto superior] [texto inferior]
 */

const memeTemplates = {
  'drake': { url: 'https://i.imgflip.com/30b1gx.jpg', name: 'Drake Desaprova', desc: 'Drake desaprova em cima, aprova em baixo' },
  'distracted': { url: 'https://i.imgflip.com/1ur9b0.jpg', name: 'Homem Distraído', desc: 'Homem olha para trás enquanto namorada fica brava' },
  'success': { url: 'https://i.imgflip.com/1bhf.jpg', name: 'Success Kid', desc: 'Criança fazendo punho em sinal de vitória' },
  'expanding-brain': { url: 'https://i.imgflip.com/1jwhww.jpg', name: 'Cérebro em Expansão', desc: '4 níveis de pensamento, do ruim ao genial' },
  'woman-yelling': { url: 'https://i.imgflip.com/345v97.jpg', name: 'Mulher Gritando', desc: 'Mulher gritando para gato confuso' },
  'this-is-fine': { url: 'https://i.imgflip.com/c2qkv.jpg', name: 'This is Fine', desc: 'Cão em fogo dizendo que está tudo bem' },
  'change-my-mind': { url: 'https://i.imgflip.com/24y43o.jpg', name: 'Mude Minha Mente', desc: 'Homem com cartaz esperando alguém discordar' },
  'surprised-pikachu': { url: 'https://i.imgflip.com/1yk6h0.png', name: 'Pikachu Surpreso', desc: 'Pikachu com expressão de surpresa' }
};

export default {
  command: ['meme', 'meme-generator', 'meeme', 'meme-gen'],
  category: 'utils',
  description: 'Gera memes com templates populares',
  usage: '.meme [template] [texto1] | [texto2]',
  run: async function (msg, sock, args, text, usedPrefix, command) {
    try {
      if (!args.length) {
        const templates = Object.entries(memeTemplates)
          .map(([k, v]) => `${k} - ${v.name}`)
          .join('\n');

        return msg.reply(
          '😂 *Gerador de Memes*\n\n' +
          'Uso: `.meme [template] [texto superior] [texto inferior]`\n\n' +
          `Templates:\n${templates}\n\n` +
          'Exemplo: `.meme drake não gosto disso | gosto muito disso`'
        );
      }

      const template = args[0].toLowerCase();
      const textoParts = args.slice(1).join(' ').split('|');

      if (!memeTemplates[template]) {
        const templates = Object.keys(memeTemplates).join(', ');
        return msg.reply(`❌ Template "${template}" não encontrado!\n\nTemplates: ${templates}`);
      }

      if (textoParts.length < 2) {
        return msg.reply('❌ Forneça dois textos separados por | (pipe)\n\nExemplo: `.meme drake texto 1 | texto 2`');
      }

      const textoSuperior = textoParts[0].trim();
      const textoInferior = textoParts[1].trim();

      if (!textoSuperior || !textoInferior) {
        return msg.reply('❌ Os dois textos não podem estar vazios!');
      }

      const processing = await msg.reply(
        `😂 Gerando meme...\n` +
        `Template: ${memeTemplates[template].name}\n` +
        `Texto 1: ${textoSuperior}\n` +
        `Texto 2: ${textoInferior}\n\n` +
        'Por favor, aguarde...'
      );

      try {
        const memeUrl = await gerarMeme(template, textoSuperior, textoInferior);

        if (!memeUrl) {
          return msg.reply('❌ Erro ao gerar meme!');
        }

        await sock.sendMessage(msg.chat, {
          image: { url: memeUrl },
          caption:
            `✅ *Meme Gerado com Sucesso!*\n\n` +
            `😂 Template: ${memeTemplates[template].name}\n` +
            `📝 Texto 1: ${textoSuperior}\n` +
            `📝 Texto 2: ${textoInferior}\n` +
            `⏰ ${new Date().toLocaleTimeString('pt-MZ')}\n\n` +
            `💡 Dica: Compartilhe nas redes sociais!`
        }, { quoted: msg });

        await sock.sendMessage(msg.chat, { delete: processing.key });

      } catch (error) {
        console.error('Erro ao gerar meme:', error);
        return msg.reply('❌ Erro ao processar meme!');
      }

    } catch (error) {
      console.error('Erro em meme_generator:', error);
      msg.reply('❌ Erro ao processar comando meme!');
    }
  }
};

async function gerarMeme(template, textoSuperior, textoInferior) {
  try {
    const templateId = getTemplateId(template);
    if (!templateId) return null;

    const text0 = encodeURIComponent(textoSuperior);
    const text1 = encodeURIComponent(textoInferior);

    const url = `https://api.imgflip.com/caption_image?template_id=${templateId}&text0=${text0}&text1=${text1}`;

    return url;

  } catch (error) {
    console.error('Erro ao gerar meme:', error);
    return null;
  }
}

function getTemplateId(template) {
  const ids = {
    'drake': '181913649',
    'distracted': '112126428',
    'success': '61579',
    'expanding-brain': '93895088',
    'woman-yelling': '124822590',
    'this-is-fine': '129242436',
    'change-my-mind': '129242436',
    'surprised-pikachu': '155067746'
  };
  return ids[template] || null;
}
