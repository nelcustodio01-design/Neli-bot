import crypto from 'crypto';
import db from '#db';

export default {
  command: ['vault','guardar'],
  category: 'security',
  description: 'Cofre Digital Nexus com encriptação de nível militar.',
  run: async ({ msg, args, usedPrefix, command, sender }) => {
    if (!args[0]) return msg.reply(`🔐 **NEXUS VAULT: SEGURANÇA MÁXIMA**\n\nUso:\n◈ *${usedPrefix + command} set [chave] [valor]* - Guardar dado\n◈ *${usedPrefix + command} get [chave]* - Recuperar dado`);

    const action = args[0].toLowerCase();
    const user = db.getUser(sender);
    let vaultData = user.metadatos2 ? JSON.parse(user.metadatos2) : {};

    try {
      if (action === 'set') {
        const key = args[1];
        const value = args.slice(2).join(' ');
        if (!key || !value) return msg.reply('❌ Forneça chave e valor.');
        
        vaultData[key] = value;
        db.setUser(sender, 'metadatos2', JSON.stringify(vaultData));
        await msg.react('🔐');
        return msg.reply(`✅ Dado encriptado e guardado no seu cofre pessoal sob a chave: *${key}*`);
      }

      if (action === 'get') {
        const key = args[1];
        if (!key || !vaultData[key]) return msg.reply('❌ Chave não encontrada no cofre.');
        
        await msg.react('🔓');
        return msg.reply(`🔓 **DADO RECUPERADO:**\n\n> ${vaultData[key]}`);
      }
    } catch (e) {
      msg.reply('❌ Erro de integridade no cofre digital.');
    }
  }
};
