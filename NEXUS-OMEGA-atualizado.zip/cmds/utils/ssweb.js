/**
 * 📸 SSWEB — Screenshot de páginas web
 * Corrigido: removido conflito de alias 'captura' com ss.js
 */
import fetch from 'node-fetch';

export default {
  command: ['ssweb', 'screenshotweb', 'webshot', 'siteshot', 'paginaweb'],
  category: 'utilidades',
  description: 'Captura screenshot de qualquer página web 📸',
  run: async ({ sock, msg, args, from, usedPrefix, command }) => {
    const url = args[0];
    if (!url) {
      return msg.reply(
        `📸 *SCREENSHOT WEB*\n\n` +
        `Uso: *${usedPrefix}${command} <URL>*\n\n` +
        `Exemplos:\n` +
        `▸ *${usedPrefix}${command} https://www.google.com*\n` +
        `▸ *${usedPrefix}${command} https://www.youtube.com*\n\n` +
        `⚠️ O link deve começar com http:// ou https://`
      );
    }

    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      return msg.reply('❌ A URL deve começar com http:// ou https://');
    }

    await msg.react('📸');

    try {
      let screenshotUrl = null;

      // Método 1: Delirius
      try {
        const res = await fetch(`https://api.delirius.store/tools/ssweb?url=${encodeURIComponent(url)}`, { timeout: 20000 });
        if (res.ok) {
          const contentType = res.headers.get('content-type') || '';
          if (contentType.includes('image')) {
            const buffer = Buffer.from(await res.arrayBuffer());
            await sock.sendMessage(from, {
              image: buffer,
              caption: `📸 *Screenshot*\n🔗 ${url}`
            }, { quoted: msg });
            await msg.react('✅');
            return;
          }
          const data = await res.json().catch(() => null);
          if (data?.result) screenshotUrl = data.result.image || data.result.url || data.result.screenshot || data.result;
        }
      } catch {}

      // Método 2: Vreden
      if (!screenshotUrl) {
        try {
          const res = await fetch(`https://api.vreden.web.id/api/v1/tools/ss?url=${encodeURIComponent(url)}`, { timeout: 20000 });
          if (res.ok) {
            const data = await res.json().catch(() => null);
            if (data?.status && data?.result) {
              screenshotUrl = typeof data.result === 'string' ? data.result : (data.result.url || data.result.image || data.result.screenshot);
            }
          }
        } catch {}
      }

      // Método 3: thum.io (sem API key)
      if (!screenshotUrl) {
        try {
          screenshotUrl = `https://image.thum.io/get/width/1280/crop/800/${url}`;
          const testRes = await fetch(screenshotUrl, { method: 'HEAD', timeout: 15000 });
          if (!testRes.ok) screenshotUrl = null;
        } catch { screenshotUrl = null; }
      }

      // Método 4: minishots.com
      if (!screenshotUrl) {
        screenshotUrl = `https://api.minishots.com/screenshot?url=${encodeURIComponent(url)}&width=1280&height=800`;
      }

      if (screenshotUrl) {
        await sock.sendMessage(from, {
          image: { url: screenshotUrl },
          caption: `📸 *Screenshot*\n🔗 ${url}\n\n💡 Use *${usedPrefix}${command}* para mais capturas!`
        }, { quoted: msg });
        await msg.react('✅');
      } else {
        await msg.reply(`❌ Não foi possível capturar o screenshot de:\n🔗 ${url}\n\nVerifica se a URL está acessível.`);
      }
    } catch (e) {
      await msg.reply(`❌ Erro: ${e.message}`);
    }
  }
};
