/**
 * .sentimento - Analisador de Sentimento
 * Detecta emoção em textos (positivo/negativo/neutro)
 * Uso: .sentimento [texto]
 */

const palavrasPositivas = [
  'bom', 'ótimo', 'excelente', 'maravilhoso', 'fantástico', 'incrível', 'adorei', 'amei',
  'feliz', 'alegre', 'gosto', 'gostei', 'legal', 'bacana', 'show', 'perfeito', 'lindo',
  'bonito', 'sucesso', 'vitória', 'ganhar', 'ganho', 'melhor', 'amo', 'amor', 'querido',
  'querida', 'queremos', 'queremos', 'gostamos', 'adoramos', 'amamos', 'excelente',
  'positivo', 'esperança', 'esperançoso', 'otimista', 'otimismo', 'bênção', 'abençoado'
];

const palavrasNegativas = [
  'ruim', 'péssimo', 'horrível', 'terrível', 'detestável', 'odeio', 'odiei', 'odiava',
  'triste', 'infeliz', 'chato', 'chata', 'entediante', 'fracasso', 'derrota', 'perder',
  'perdi', 'pior', 'feio', 'feia', 'desagradável', 'desagradável', 'negativo', 'negatividade',
  'desesperança', 'desesperado', 'pessimista', 'pessimismo', 'maldição', 'amaldiçoado',
  'problema', 'problemas', 'erro', 'erros', 'falha', 'falhas', 'decepção', 'decepcionante'
];

export default {
  command: ['sentimento', 'analise-sentimento', 'emoção', 'emocao'],
  category: 'utils',
  description: 'Analisa o sentimento de um texto',
  usage: '.sentimento [texto]',
  run: async function (msg, sock, args, text, usedPrefix, command) {
    try {
      let textoAnalisar = '';

      if (!args.length && !msg.quoted) {
        return msg.reply(
          '😊 *Analisador de Sentimento*\n\n' +
          'Uso: `.sentimento [texto]` ou responda a uma mensagem\n\n' +
          'Detecta: Positivo, Negativo ou Neutro\n\n' +
          'Exemplos:\n' +
          '• `.sentimento Adorei este produto, é maravilhoso!`\n' +
          '• `.sentimento Que dia horrível, tudo deu errado.`'
        );
      }

      if (msg.quoted) {
        textoAnalisar = msg.quoted.body || msg.quoted.text || '';
      } else {
        textoAnalisar = args.join(' ');
      }

      if (!textoAnalisar || textoAnalisar.length < 10) {
        return msg.reply('❌ O texto é muito curto! Mínimo 10 caracteres.');
      }

      if (textoAnalisar.length > 1000) {
        return msg.reply('❌ O texto é muito longo! Máximo 1000 caracteres.');
      }

      const processing = await msg.reply(
        '🔍 Analisando sentimento...\n' +
        `Texto: ${textoAnalisar.substring(0, 50)}...\n\n` +
        'Por favor, aguarde...'
      );

      try {
        const resultado = analisarSentimento(textoAnalisar);

        if (!resultado) {
          return msg.reply('❌ Erro ao analisar sentimento!');
        }

        let emoji = '😐';
        if (resultado.sentimento === 'positivo') emoji = '😊';
        if (resultado.sentimento === 'negativo') emoji = '😞';

        const barraPositiva = '█'.repeat(Math.round(resultado.positivo * 10)) + '░'.repeat(10 - Math.round(resultado.positivo * 10));
        const barraNegativa = '█'.repeat(Math.round(resultado.negativo * 10)) + '░'.repeat(10 - Math.round(resultado.negativo * 10));
        const barraNeutra = '█'.repeat(Math.round(resultado.neutro * 10)) + '░'.repeat(10 - Math.round(resultado.neutro * 10));

        const mensagem =
          `${emoji} *Análise de Sentimento*\n\n` +
          `📝 *Texto Analisado:*\n"${textoAnalisar}"\n\n` +
          `🎯 *Resultado:*\n` +
          `Sentimento: ${resultado.sentimento.toUpperCase()}\n` +
          `Confiança: ${resultado.confianca}%\n\n` +
          `📊 *Distribuição:*\n` +
          `😊 Positivo: ${barraPositiva} ${(resultado.positivo * 100).toFixed(1)}%\n` +
          `😞 Negativo: ${barraNegativa} ${(resultado.negativo * 100).toFixed(1)}%\n` +
          `😐 Neutro: ${barraNeutra} ${(resultado.neutro * 100).toFixed(1)}%\n\n` +
          `📈 *Análise Detalhada:*\n` +
          `• Palavras Positivas: ${resultado.palavrasPositivas}\n` +
          `• Palavras Negativas: ${resultado.palavrasNegativas}\n` +
          `• Total de Palavras: ${resultado.totalPalavras}\n` +
          `• Comprimento do Texto: ${textoAnalisar.length} caracteres\n\n` +
          `⏰ ${new Date().toLocaleTimeString('pt-MZ')}`;

        await sock.sendMessage(msg.chat, { text: mensagem }, { quoted: msg });
        await sock.sendMessage(msg.chat, { delete: processing.key });

      } catch (error) {
        console.error('Erro ao analisar:', error);
        return msg.reply('❌ Erro ao processar análise!');
      }

    } catch (error) {
      console.error('Erro em analise_sentimento:', error);
      msg.reply('❌ Erro ao processar comando sentimento!');
    }
  }
};

function analisarSentimento(texto) {
  try {
    const textoLower = texto.toLowerCase();
    const palavras = textoLower.split(/\s+/);

    let positivos = 0;
    let negativos = 0;
    const totalPalavras = palavras.length;

    palavras.forEach(palavra => {
      const palavraLimpa = palavra.replace(/[^\w]/g, '');
      if (palavrasPositivas.includes(palavraLimpa)) {
        positivos++;
      } else if (palavrasNegativas.includes(palavraLimpa)) {
        negativos++;
      }
    });

    const totalSentimento = positivos + negativos || 1;
    const propPositivo = positivos / totalSentimento;
    const propNegativo = negativos / totalSentimento;
    const propNeutro = 1 - propPositivo - propNegativo;

    let sentimento = 'neutro';
    let confianca = 0;

    if (propPositivo > propNegativo && propPositivo > 0.4) {
      sentimento = 'positivo';
      confianca = Math.round(propPositivo * 100);
    } else if (propNegativo > propPositivo && propNegativo > 0.4) {
      sentimento = 'negativo';
      confianca = Math.round(propNegativo * 100);
    } else {
      sentimento = 'neutro';
      confianca = Math.round(propNeutro * 100);
    }

    return {
      sentimento,
      confianca,
      positivo: propPositivo,
      negativo: propNegativo,
      neutro: propNeutro,
      palavrasPositivas: positivos,
      palavrasNegativas: negativos,
      totalPalavras
    };

  } catch (error) {
    console.error('Erro ao analisar sentimento:', error);
    return null;
  }
}
