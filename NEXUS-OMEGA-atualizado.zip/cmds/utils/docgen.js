/**
 * .docgen - Criador de Documentos Word
 * Gera ficheiros .docx estruturados com conteúdo solicitado
 * Uso: .docgen [título] | [conteúdo]
 */

import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType } from 'docx';
import { writeFileSync } from 'fs';
import { join } from 'path';
import { randomBytes } from 'crypto';

export default {
  command: ['docgen', 'doc', 'word', 'documento'],
  category: 'utils',
  description: 'Gera documentos Word profissionais',
  usage: '.docgen [título] | [conteúdo]',
  ownerOnly: true,
  run: async function (msg, sock, args, text, usedPrefix, command, isOwner) {
    try {
      if (!isOwner) {
        return msg.reply('❌ Este comando é exclusivo para donos do bot!');
      }

      if (!args.length) {
        return msg.reply(
          '📄 *Gerador de Documentos Word*\n\n' +
          'Uso: `.docgen [título] | [conteúdo]`\n\n' +
          'Exemplo:\n' +
          '`.docgen Relatório Mensal | Este é o conteúdo do relatório...`\n\n' +
          'O bot criará um ficheiro .docx profissional e enviará para você!'
        );
      }

      const fullText = args.join(' ');
      const [title, ...contentParts] = fullText.split('|');

      if (!title || !contentParts.length) {
        return msg.reply('❌ Formato inválido! Use: `.docgen [título] | [conteúdo]`');
      }

      const content = contentParts.join('|').trim();

      const processing = await msg.reply(
        '📝 Gerando documento Word...\n' +
        `Título: ${title.trim()}\n\n` +
        'Por favor, aguarde...'
      );

      try {
        const docPath = await generateWordDocument(title.trim(), content);

        if (!docPath) {
          return msg.reply('❌ Erro ao gerar documento!');
        }

        await sock.sendMessage(msg.chat, {
          document: { url: `file://${docPath}` },
          mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          fileName: `${title.trim().replace(/\s+/g, '_')}.docx`,
          caption:
            `✅ *Documento Gerado com Sucesso!*\n\n` +
            `📄 Título: ${title.trim()}\n` +
            `⏰ Data: ${new Date().toLocaleDateString('pt-MZ')}\n` +
            `🤖 Gerador: Nel-Aviso-Bot`
        }, { quoted: msg });

        await sock.sendMessage(msg.chat, { delete: processing.key });

      } catch (error) {
        console.error('Erro ao gerar documento:', error);
        return msg.reply('❌ Erro ao processar documento!');
      }

    } catch (error) {
      console.error('Erro em docgen:', error);
      msg.reply('❌ Erro ao processar comando docgen!');
    }
  }
};

async function generateWordDocument(title, content) {
  try {
    const paragraphs = content.split('\n').filter(p => p.trim());

    const doc = new Document({
      sections: [{
        children: [
          new Paragraph({
            text: title,
            heading: HeadingLevel.HEADING_1,
            alignment: AlignmentType.CENTER,
            spacing: { after: 400 },
            run: new TextRun({
              bold: true,
              size: 32,
              color: '1F4E78'
            })
          }),
          new Paragraph({
            text: `Data: ${new Date().toLocaleDateString('pt-MZ')}`,
            alignment: AlignmentType.RIGHT,
            spacing: { after: 600 },
            run: new TextRun({
              italics: true,
              size: 20,
              color: '666666'
            })
          }),
          new Paragraph({
            text: '─'.repeat(50),
            alignment: AlignmentType.CENTER,
            spacing: { after: 400 }
          }),
          ...paragraphs.map((para) =>
            new Paragraph({
              text: para,
              spacing: { line: 360, after: 200 },
              alignment: AlignmentType.LEFT,
              run: new TextRun({
                size: 22,
                color: '000000'
              })
            })
          ),
          new Paragraph({
            text: '',
            spacing: { after: 400 }
          }),
          new Paragraph({
            text: '─'.repeat(50),
            alignment: AlignmentType.CENTER,
            spacing: { after: 200 }
          }),
          new Paragraph({
            text: `Gerado por Nel-Aviso-Bot • ${new Date().toLocaleTimeString('pt-MZ')}`,
            alignment: AlignmentType.CENTER,
            run: new TextRun({
              italics: true,
              size: 18,
              color: '999999'
            })
          })
        ]
      }]
    });

    const fileName = `doc_${randomBytes(4).toString('hex')}.docx`;
    const filePath = join(process.cwd(), 'temp', fileName);
    const buffer = await Packer.toBuffer(doc);
    writeFileSync(filePath, buffer);

    return filePath;

  } catch (error) {
    console.error('Erro ao criar documento Word:', error);
    return null;
  }
}
