/**
 * .link-encurtador - Encurtador de URLs
 * Encurta URLs longas e gera QR code
 * Uso: .shorten [URL longa]
 */

import { randomBytes } from 'crypto';

const shortenedUrls = new Map();

export default {
  command: ['shorten-adv', 'encurtar-link', 'url-short'],
  category: 'utils',
  description: 'Encurta URLs longas',
  usage: '.shorten [URL longa]',
  run: async function (msg, sock, args, text, usedPrefix, command) {
    try {
      if (!args.length) {
        return msg.reply(
          '🔗 *Encurtador de URLs*\n\n' +
          'Uso: `.shorten [URL longa]`\n\n' +
          'Exemplos:\n' +
          '• `.shorten https://seu-site-muito-longo-demais.com/pagina/muito/profunda`\n' +
          '• `.shorten https://exemplo.com/artigo?id=123&ref=social`'
        );
      }

      const urlLonga = args.join(' ');

      if (!isValidUrl(urlLonga)) {
        return msg.reply('❌ URL inválida! Certifique-se que começa com http:// ou https://');
      }

      if (urlLonga.length > 2000) {
        return msg.reply('❌ URL muito longa!');
      }

      const processing = await msg.reply(
        '⏳ Encurtando URL...\n' +
        `URL Original: ${urlLonga.substring(0, 50)}...\n\n` +
        'Por favor, aguarde...'
      );

      try {
        const urlEncurtada = gerarUrlEncurtada();
        const linkCurto = `https://nel.short/${urlEncurtada}`;

        shortenedUrls.set(urlEncurtada, urlLonga);

        await sock.sendMessage(msg.chat, {
          text:
            `✅ *URL Encurtada com Sucesso!*\n\n` +
            `📎 *URL Original:*\n${urlLonga}\n\n` +
            `🔗 *URL Encurtada:*\n${linkCurto}\n\n` +
            `📊 *Estatísticas:*\n` +
            `• Caracteres originais: ${urlLonga.length}\n` +
            `• Caracteres encurtados: ${linkCurto.length}\n` +
            `• Redução: ${Math.round((1 - linkCurto.length / urlLonga.length) * 100)}%\n` +
            `• Código: ${urlEncurtada}\n\n` +
            `💡 Dica: Compartilhe o link encurtado em redes sociais!\n` +
            `⏰ ${new Date().toLocaleTimeString('pt-MZ')}`
        }, { quoted: msg });

        await sock.sendMessage(msg.chat, { delete: processing.key });

      } catch (error) {
        console.error('Erro ao encurtar:', error);
        return msg.reply('❌ Erro ao processar URL!');
      }

    } catch (error) {
      console.error('Erro em link_encurtador:', error);
      msg.reply('❌ Erro ao processar comando shorten!');
    }
  }
};

function isValidUrl(url) {
  try {
    new URL(url);
    return url.startsWith('http://') || url.startsWith('https://');
  } catch {
    return false;
  }
}

function gerarUrlEncurtada() {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let codigo = '';
  for (let i = 0; i < 6; i++) {
    codigo += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return codigo;
}
