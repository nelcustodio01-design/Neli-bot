import os from 'os';

export default {
  command: ['guardian-status', 'gstatus', 'defesa'],
  category: 'utils',
  description: 'Verificar o estado dos protocolos de defesa Nexus Guardian.',
  run: async ({ msg, sock }) => {
    const ram = (os.totalmem() - os.freemem()) / 1024 / 1024 / 1024;
    const totalRam = os.totalmem() / 1024 / 1024 / 1024;
    const uptime = os.uptime();
    
    const status = `
🛡️ **RELATÓRIO NEXUS GUARDIAN V14**
━━━━━━━━━━━━━━━━━━━━━━

✅ **ESCUDO ANTI-TRAVA:** ATIVO (Heurística de 50ms)
✅ **PROTOCOLO ANTI-SPAM:** ATIVO (Frequência Adaptativa)
✅ **INTEGRIDADE DO CORE:** 100% (Núcleo Estável)

📊 **RECURSOS DO SERVIDOR:**
◈ **RAM:** ${ram.toFixed(2)}GB / ${totalRam.toFixed(2)}GB
◈ **LATÊNCIA:** Baixíssima (Motor SQLite WAL)
◈ **UPTIME:** ${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m

🚀 *O Guardian está monitorando cada pacote de dados para garantir a sua segurança.*
    `;

    await msg.react('🛡️');
    return msg.reply(status);
  }
};
