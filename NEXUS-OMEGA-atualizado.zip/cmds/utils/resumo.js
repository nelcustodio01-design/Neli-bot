/**
 * .resumo - Gerador de Resumos Inteligentes
 * Extrai pontos-chave de um texto usando IA
 * Uso: .resumo [texto longo]
 */

export default {
  command: ['resumo-ia', 'resumo-smart', 'summary-ia'],
  category: 'utils',
  description: 'Gera resumo inteligente de textos',
  usage: '.resumo [texto]',
  run: async function (msg, sock, args, text, usedPrefix, command) {
    try {
      if (!args.length && !msg.quoted) {
        return msg.reply(
          '📝 *Gerador de Resumos*\n\n' +
          'Uso: `.resumo [texto]` ou responda a uma mensagem\n\n' +
          'Extrai os pontos-chave do texto em 3-5 linhas!'
        );
      }

      let textToSummarize = '';

      if (msg.quoted) {
        textToSummarize = msg.quoted.body || msg.quoted.text || '';
      } else {
        textToSummarize = args.join(' ');
      }

      if (!textToSummarize || textToSummarize.length < 50) {
        return msg.reply('❌ O texto é muito curto! Mínimo 50 caracteres.');
      }

      if (textToSummarize.length > 5000) {
        return msg.reply('❌ O texto é muito longo! Máximo 5000 caracteres.');
      }

      const processing = await msg.reply(
        '⏳ Gerando resumo...\n' +
        `Caracteres: ${textToSummarize.length}\n\n` +
        'Por favor, aguarde...'
      );

      try {
        const summary = await generateSummary(textToSummarize);

        if (!summary) {
          return msg.reply('❌ Erro ao gerar resumo!');
        }

        await sock.sendMessage(msg.chat, {
          text:
            `✅ *Resumo Gerado com Sucesso!*\n\n` +
            `📋 *Resumo:*\n${summary}\n\n` +
            `📊 *Estatísticas:*\n` +
            `• Texto original: ${textToSummarize.length} caracteres\n` +
            `• Resumo: ${summary.length} caracteres\n` +
            `• Redução: ${Math.round((1 - summary.length / textToSummarize.length) * 100)}%\n` +
            `⏰ ${new Date().toLocaleTimeString('pt-MZ')}`
        }, { quoted: msg });

        await sock.sendMessage(msg.chat, { delete: processing.key });

      } catch (error) {
        console.error('Erro ao gerar resumo:', error);
        return msg.reply('❌ Erro ao processar resumo!');
      }

    } catch (error) {
      console.error('Erro em resumo:', error);
      msg.reply('❌ Erro ao processar comando resumo!');
    }
  }
};

async function generateSummary(text) {
  try {
    const sentences = text.match(/[^.!?]+[.!?]+/g) || [];
    if (sentences.length === 0) return null;

    const words = text.toLowerCase().split(/\s+/);
    const freq = {};

    words.forEach(word => {
      if (word.length > 3) {
        freq[word] = (freq[word] || 0) + 1;
      }
    });

    const scored = sentences.map(sent => ({
      sentence: sent.trim(),
      score: sent.split(/\s+/).reduce((sum, word) => sum + (freq[word.toLowerCase()] || 0), 0)
    }));

    const topSentences = scored
      .sort((a, b) => b.score - a.score)
      .slice(0, Math.ceil(sentences.length * 0.3))
      .sort((a, b) => sentences.indexOf(a.sentence) - sentences.indexOf(b.sentence))
      .map(s => s.sentence);

    return topSentences.join(' ').trim();

  } catch (error) {
    console.error('Erro ao calcular resumo:', error);
    return null;
  }
}
