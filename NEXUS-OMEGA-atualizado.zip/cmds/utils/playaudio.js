import axios from 'axios';

export default {
  command: ['m', 'audio'],
  category: 'downloads',
  description: 'Procura e descarrega uma música pelo nome.',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    const query = args.join(' ');
    if (!query) return msg.reply(`🎵 **NEXUS MUSIC SEARCH**\n\nUso: *${usedPrefix + command} [nome da música]*\nExemplo: *${usedPrefix + command} Travis Scott Goosebumps*`);

    await msg.react('🎵');
    await msg.reply(`🎵 **NEXUS ENGINE:** Sintonizando "${query}" em alta fidelidade...`);

    try {
      const searchUrl = `https://api.vreden.web.id/api/search/youtube?query=${encodeURIComponent(query)}`;
      const searchRes = await axios.get(searchUrl);
      const video = searchRes.data?.result?.[0];

      if (!video) return msg.reply('❌ Nenhuma música encontrada.');

      const videoUrl = video.url;
      
      const downloadUrl = `https://api.vreden.web.id/api/download/ytmp3?url=${encodeURIComponent(videoUrl)}`;
      const downloadRes = await axios.get(downloadUrl);
      const dlLink = downloadRes.data?.result?.download?.url || downloadRes.data?.result?.url;

      if (!dlLink) throw new Error('Download link not found');

      await sock.sendMessage(msg.chat, { 
        audio: { url: dlLink }, 
        mimetype: 'audio/mp4',
        ptt: false
      }, { quoted: msg });

      await msg.react('✅');
    } catch (e) {
      console.error('Music Download Error:', e);
      msg.reply('❌ Erro ao capturar áudio neural.');
    }
  }
};
