/**
 * .tradutor - Tradutor Avançado com Contexto
 * Traduz textos para múltiplos idiomas
 * Uso: .tradutor [idioma] [texto]
 */

const idiomas = {
  'en': 'Inglês',
  'es': 'Espanhol',
  'fr': 'Francês',
  'de': 'Alemão',
  'it': 'Italiano',
  'pt': 'Português',
  'ru': 'Russo',
  'ja': 'Japonês',
  'zh': 'Chinês',
  'ar': 'Árabe',
  'hi': 'Hindi',
  'ko': 'Coreano'
};

export default {
  command: ['tradutor-adv', 'tradv', 'traducao-adv'],
  category: 'utils',
  description: 'Traduz textos para múltiplos idiomas',
  usage: '.tradutor [idioma] [texto]',
  run: async function (msg, sock, args, text, usedPrefix, command) {
    try {
      if (!args.length) {
        const langs = Object.entries(idiomas).map(([k, v]) => `${k} - ${v}`).join('\n');
        return msg.reply(
          '🌐 *Tradutor Avançado*\n\n' +
          'Uso: `.tradutor [idioma] [texto]`\n\n' +
          `Idiomas disponíveis:\n${langs}\n\n` +
          'Exemplo: `.tradutor en olá, como vai?`'
        );
      }

      const idiomaCode = args[0].toLowerCase();
      const textToTranslate = args.slice(1).join(' ');

      if (!idiomas[idiomaCode]) {
        return msg.reply(`❌ Idioma "${idiomaCode}" não encontrado!`);
      }

      if (!textToTranslate) {
        return msg.reply('❌ Forneça um texto para traduzir!');
      }

      if (textToTranslate.length > 1000) {
        return msg.reply('❌ Texto muito longo! Máximo 1000 caracteres.');
      }

      const processing = await msg.reply(
        `🔄 Traduzindo para ${idiomas[idiomaCode]}...\n` +
        `Texto: ${textToTranslate}\n\n` +
        'Por favor, aguarde...'
      );

      try {
        const translated = await translateText(textToTranslate, idiomaCode);

        if (!translated) {
          return msg.reply('❌ Erro ao traduzir!');
        }

        await sock.sendMessage(msg.chat, {
          text:
            `✅ *Tradução Concluída!*\n\n` +
            `🌐 Idioma: ${idiomas[idiomaCode]}\n\n` +
            `📝 *Original (PT):*\n${textToTranslate}\n\n` +
            `🔤 *Traduzido (${idiomaCode.toUpperCase()}):*\n${translated}\n\n` +
            `📊 Caracteres:\n` +
            `• Original: ${textToTranslate.length}\n` +
            `• Tradução: ${translated.length}\n` +
            `⏰ ${new Date().toLocaleTimeString('pt-MZ')}`
        }, { quoted: msg });

        await sock.sendMessage(msg.chat, { delete: processing.key });

      } catch (error) {
        console.error('Erro ao traduzir:', error);
        return msg.reply('❌ Erro ao processar tradução!');
      }

    } catch (error) {
      console.error('Erro em tradutor:', error);
      msg.reply('❌ Erro ao processar comando tradutor!');
    }
  }
};

async function translateText(text, targetLang) {
  try {
    const response = await fetch('https://api.mymemory.translated.net/get', {
      method: 'GET',
      headers: {
        'User-Agent': 'Nel-Aviso-Bot/1.0'
      },
      body: new URLSearchParams({
        q: text,
        langpair: `pt|${targetLang}`
      }).toString()
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.status}`);
    }

    const data = await response.json();
    return data.responseData?.translatedText || null;

  } catch (error) {
    console.error('Erro ao chamar API de tradução:', error);
    return null;
  }
}
