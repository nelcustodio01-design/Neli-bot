/**
 * .quote - Citações Inspiradoras do Dia
 * Fornece citações aleatórias por categoria
 * Uso: .quote [categoria opcional]
 */

const quotes = {
  'sucesso': [
    { texto: 'O sucesso não é final, o fracasso não é fatal.', autor: 'Winston Churchill' },
    { texto: 'Não é sobre quanto você ganha, é sobre quanto você guarda.', autor: 'Robert Kiyosaki' },
    { texto: 'A jornada de mil milhas começa com um único passo.', autor: 'Lao Tzu' },
    { texto: 'O único lugar onde o sucesso vem antes do trabalho é no dicionário.', autor: 'Vidal Sassoon' },
    { texto: 'Você não pode construir uma reputação com o que você vai fazer.', autor: 'Henry Ford' }
  ],
  'motivação': [
    { texto: 'Acredite em si mesmo. Você é mais forte do que pensa.', autor: 'Desconhecido' },
    { texto: 'Não é sobre ser o melhor, é sobre ser melhor do que você era ontem.', autor: 'Desconhecido' },
    { texto: 'A vida é 10% o que acontece com você e 90% como você reage.', autor: 'Charles R. Swindoll' },
    { texto: 'Você é capaz de mais do que você imagina.', autor: 'Desconhecido' },
    { texto: 'Cada dia é uma nova oportunidade para mudar sua vida.', autor: 'Desconhecido' }
  ],
  'amor': [
    { texto: 'O amor é a coisa mais poderosa do mundo.', autor: 'Desconhecido' },
    { texto: 'Amar é encontrar sua paz em outra pessoa.', autor: 'Robert Browning' },
    { texto: 'O amor verdadeiro não é sobre perfeição, é sobre aceitação.', autor: 'Desconhecido' },
    { texto: 'A vida sem amor é como uma árvore sem flores.', autor: 'Khalil Gibran' },
    { texto: 'Amar é dar sem esperar receber.', autor: 'Desconhecido' }
  ],
  'humor': [
    { texto: 'A vida é muito curta para ser levada a sério.', autor: 'Oscar Wilde' },
    { texto: 'Rir é o melhor remédio, exceto para asma.', autor: 'Markus Zusak' },
    { texto: 'Quanto mais velho fico, menos paciência tenho com as pessoas.', autor: 'Desconhecido' },
    { texto: 'Café: porque a violência não é a resposta.', autor: 'Desconhecido' },
    { texto: 'Eu não sou preguiçoso, apenas energeticamente eficiente.', autor: 'Desconhecido' }
  ],
  'sabedoria': [
    { texto: 'A sabedoria é conhecer o que fazer; a virtude é fazê-lo.', autor: 'David Starr Jordan' },
    { texto: 'Não é a montanha que conquistamos, mas a nós mesmos.', autor: 'Edmund Hillary' },
    { texto: 'O conhecimento é poder, mas a sabedoria é saber como usá-lo.', autor: 'Desconhecido' },
    { texto: 'A verdadeira sabedoria vem de saber o quanto você não sabe.', autor: 'Sócrates' },
    { texto: 'A vida é um professor, se você estiver disposto a aprender.', autor: 'Desconhecido' }
  ],
  'negócios': [
    { texto: 'O dinheiro não é tudo, mas é importante.', autor: 'Robert Kiyosaki' },
    { texto: 'Oportunidade é aquela pequena coisa que você não vê vindo.', autor: 'Desconhecido' },
    { texto: 'O melhor momento para plantar uma árvore foi há 20 anos. O segundo melhor é agora.', autor: 'Provérbio Chinês' },
    { texto: 'Não coloque todos os ovos na mesma cesta.', autor: 'Provérbio' },
    { texto: 'O risco é o preço do progresso.', autor: 'Desconhecido' }
  ]
};

export default {
  command: ['dailyquote', 'citacaodia', 'inspiracao'],
  category: 'utils',
  description: 'Fornece citações inspiradoras aleatórias',
  usage: '.quote [categoria]',
  run: async function (msg, sock, args, text, usedPrefix, command) {
    try {
      const categoria = args[0]?.toLowerCase() || 'sucesso';

      if (categoria !== 'random' && !quotes[categoria]) {
        const categorias = Object.keys(quotes).join(', ');
        return msg.reply(
          '💭 *Citações Inspiradoras*\n\n' +
          'Uso: `.quote [categoria]`\n\n' +
          `Categorias: ${categorias}\n\n` +
          'Exemplos:\n' +
          '• `.quote sucesso`\n' +
          '• `.quote motivação`\n' +
          '• `.quote random`'
        );
      }

      let categoriaSelecionada;
      let quote;

      if (categoria === 'random') {
        const categorias = Object.keys(quotes);
        categoriaSelecionada = categorias[Math.floor(Math.random() * categorias.length)];
      } else {
        categoriaSelecionada = categoria;
      }

      const quotesCategoria = quotes[categoriaSelecionada];
      quote = quotesCategoria[Math.floor(Math.random() * quotesCategoria.length)];

      const mensagem =
        `💭 *Citação do Dia*\n\n` +
        `"${quote.texto}"\n\n` +
        `— ${quote.autor}\n\n` +
        `📂 Categoria: ${categoriaSelecionada.toUpperCase()}\n` +
        `📅 Data: ${new Date().toLocaleDateString('pt-MZ')}\n` +
        `⏰ ${new Date().toLocaleTimeString('pt-MZ')}\n\n` +
        `✨ Que esta citação inspire seu dia!`;

      await sock.sendMessage(msg.chat, { text: mensagem }, { quoted: msg });

    } catch (error) {
      console.error('Erro em quote_dia:', error);
      msg.reply('❌ Erro ao processar comando quote!');
    }
  }
};
