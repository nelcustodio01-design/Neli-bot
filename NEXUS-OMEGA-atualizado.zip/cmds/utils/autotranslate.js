import axios from 'axios';

export default {
  command: ['autotr', 'traduzir-chat'],
  category: 'utils',
  description: 'Traduz automaticamente a última mensagem respondida.',
  run: async ({ msg, sock, args }) => {
    const q = msg.quoted ? msg.quoted : null;
    if (!q || !q.text) return msg.reply('🌍 **NEXUS AUTO-TR:** Responda a uma mensagem de texto para traduzi-la instantaneamente.');

    const targetLang = args[0] || 'pt';
    await msg.react('🌍');

    try {
      const url = `https://api.vreden.web.id/api/tools/translate?text=${encodeURIComponent(q.text)}&to=${targetLang}`;
      const response = await axios.get(url);
      const translated = response.data?.result || "Não foi possível traduzir.";

      return msg.reply(`🌍 **TRADUÇÃO NEXUS:**\n\n${translated}`);
    } catch (e) {
      msg.reply('❌ Falha no motor de tradução neural.');
    }
  }
};
