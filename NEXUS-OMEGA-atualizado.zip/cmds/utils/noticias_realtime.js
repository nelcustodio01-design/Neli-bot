/**
 * 📰 NOTÍCIAS REALTIME — Motor de notícias em tempo real
 * Corrigido: removida chave placeholder, usa APIs públicas
 */
import fetch from 'node-fetch';

export default {
  command: ['noticias', 'news', 'noticia', 'jornal', 'atualidade'],
  category: 'utilidades',
  description: 'Ver notícias em tempo real de qualquer tema 📰',
  run: async ({ msg, sock, args, usedPrefix, command }) => {
    try {
      const query = args.join(' ').trim() || 'Moçambique';
      await msg.react('📰');
      await msg.reply(`📰 *Buscando notícias sobre "${query}"...*`);

      let noticias = [];

      // API 1: Vreden Google Search
      try {
        const res = await fetch(
          `https://api.vreden.web.id/api/search/google?query=noticias+${encodeURIComponent(query)}`,
          { timeout: 12000 }
        );
        const data = await res.json();
        const results = data?.result || data?.results || [];
        if (results.length) {
          noticias = results.slice(0, 7).map(n => ({
            title: n.title,
            desc: n.snippet || n.description || '',
            url: n.link || n.url,
            source: n.source || 'Web'
          }));
        }
      } catch {}

      // API 2: Delirius Search
      if (!noticias.length) {
        try {
          const res = await fetch(
            `https://api.delirius.store/search/google?query=noticias+${encodeURIComponent(query)}&num=7`,
            { timeout: 12000 }
          );
          const data = await res.json();
          const results = data?.result || data?.data || [];
          if (results.length) {
            noticias = results.slice(0, 7).map(n => ({
              title: n.title,
              desc: n.description || n.snippet || '',
              url: n.url || n.link,
              source: n.source || 'Web'
            }));
          }
        } catch {}
      }

      // API 3: Siputzx Search
      if (!noticias.length) {
        try {
          const res = await fetch(
            `https://api.siputzx.my.id/api/search/google?query=noticias+${encodeURIComponent(query)}&num=7`,
            { timeout: 12000 }
          );
          const data = await res.json();
          const results = data?.data || data?.result || [];
          if (results.length) {
            noticias = results.slice(0, 7).map(n => ({
              title: n.title,
              desc: n.snippet || n.description || '',
              url: n.link || n.url,
              source: 'Web'
            }));
          }
        } catch {}
      }

      if (!noticias.length) {
        return msg.reply(`❌ Não foi possível obter notícias sobre "${query}". Tenta novamente.`);
      }

      let texto = `📰 *NOTÍCIAS — ${query.toUpperCase()}*\n`;
      texto += `━━━━━━━━━━━━━━━━━━━━\n\n`;

      noticias.forEach((n, i) => {
        texto += `${i + 1}. *${n.title || 'Sem título'}*\n`;
        if (n.desc) texto += `   ${n.desc.substring(0, 130)}...\n`;
        if (n.source) texto += `   📡 ${n.source}`;
        if (n.url) texto += ` · 🔗 ${n.url}`;
        texto += '\n\n';
      });

      texto += `🔍 *${usedPrefix}${command} <tema>* para buscar mais`;

      await msg.reply(texto.trim());
    } catch (e) {
      msg.reply(`❌ Erro ao buscar notícias: ${e.message}`);
    }
  }
};
