// Este ficheiro foi unificado com extras/afk.js
// Redireccionado para evitar conflito de comandos duplicados
import DB from '#db';

export default {
  // Comandos diferentes dos de extras/afk.js para evitar colisão
  command: ['voltei', 'back', 'saiuafk'],
  category: 'perfil',
  description: 'Remover modo AFK manualmente. ↩️',
  run: async ({ msg }) => {
    const user = DB.getUser(msg.sender);
    if (!user?.afk) {
      return msg.reply('✎ Não estás em modo AFK actualmente.');
    }
    DB.setUser(msg.sender, 'afk', 0);
    DB.setUser(msg.sender, 'afkReason', '');
    return msg.reply(`✅ *AFK removido!*\nBem-vindo(a) de volta, *${user.name || msg.sender.split('@')[0]}*!`);
  }
};
