import settings from '#settings';
import DB from '#db';
export default {
  command: ['cosplay', 'cosplaynsfw', 'cos'],
  category: 'nsfw',
  description: 'Cosplay NSFW',
  nsfw: true,
  async run({ msg, sock, args, text, isGroup, chatId }) {
    await msg.reply(`🔞 A buscar: _cosplay_\n\n⏳ Aguarde...`);
  },
};
