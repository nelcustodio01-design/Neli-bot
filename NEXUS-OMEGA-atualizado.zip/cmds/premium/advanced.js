/**
 * Categoria premium removida por solicitação do utilizador.
 * Este ficheiro está desativado.
 */
export default {
  command: ['_premium_disabled'],
  category: 'owner',
  description: 'Desativado',
  run: async ({ msg }) => {}
};
